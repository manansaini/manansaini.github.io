<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" class="error-search-form nictitate-search-form">
	<input type="text" name="s" placeholder="<?php echo esc_html__( 'Search', 'nictitate-lite-ii' ); ?>">
</form>