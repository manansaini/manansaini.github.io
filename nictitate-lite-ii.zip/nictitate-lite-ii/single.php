<?php
get_header();
get_template_part( 'template/breadcrumb' );
$layout_id = nictitate_lite_ii_get_template_setting();
$template  = apply_filters( 'nictitate_lite_ii_get_single_template', sprintf( 'template/single/%s', $layout_id ) );
get_template_part( $template );
get_footer();