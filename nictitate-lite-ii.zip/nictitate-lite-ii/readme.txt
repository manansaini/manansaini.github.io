Nictitate Lite II Theme
--------------------
Nictitate theme is designed for portfolios, corporate and e-commerce with flexible layout. The theme is based on KOPATHEME layout manager technique that will let you flexibility choose layout options of every pages within your site. It is very helpful when you are experimenting with visual hierarchy. You can define unlimited sidebar for widget areas, and with powerful custom widgets, the theme provides you more flexibility and ease-of-use for your site

--------------------
Changelog
--------------------
* 1.0.0 (3/23/2015)
- firtst version

--------------------
Sources and Credits
--------------------

--------------------
Font Awesome License
--------------------

Font License - http://fontawesome.io
License: SIL OFL 1.1
License URI: http://scripts.sil.org/OFL
Copyright: Dave Gandy, http://fontawesome.io

Code License - http://fontawesome.io
License: MIT License
License URI: http://opensource.org/licenses/mit-license.html
Copyright: Dave Gandy, http://fontawesome.io

Brand Icons
All brand icons are trademarks of their respective owners.
The use of these trademarks does not indicate endorsement of the trademark holder by Font Awesome, nor vice versa.


--------------------
Other Licenses
--------------------
See headers of files for further details.


--------------------
Screenshot
--------------------
All image with license CC0

https://pixabay.com/en/student-typing-keyboard-text-woman-849825/

--------------------
Javascript Licenses
--------------------
    bootstrap.js
        Bootstrap v3.3.4 (http://getbootstrap.com)
        Copyright 2011-2015 Twitter, Inc
        Licensed under MIT (https://github.com/twbs/bootstrap/blob/master/LICENSE)
    classie.js
        Bonzo is Copyright © 2014 Dustin Diaz @ded and licensed under the MIT licence
    count-up.js
        Copyright 2014-2015 @inorganik
        Licensed under the MIT license
    custom.js
        Copyright (c) 2016 Kopatheme - kopatheme.com
        Licensed under the GPL license:
        http://www.gnu.org/licenses/gpl.html   
    elevate-zoom.js
        jQuery elevateZoom 3.0.8
        Copyright (c) 2012 Andrew Eades - www.elevateweb.co.uk
        Dual licensed under the GPL and MIT licenses.
        http://en.wikipedia.org/wiki/MIT_License
        http://en.wikipedia.org/wiki/GNU_General_Public_License
    fractionslider.js
        jQuery Fraction Slider v0.9.101
        Copyright 2013, jacksbox.design
        Free to use under the MIT license
        http://www.opensource.org/licenses/mit-license.php
    gmap.init.js
        Copyright (c) 2016 Kopatheme - kopatheme.com
        Licensed under the GPL license:
        http://www.gnu.org/licenses/gpl.html   
    gmap.js
        GMaps.js v0.4.21 - http://hpneo.github.com/gmaps/
        Copyright 2015, Gustavo Leon
        Released under the MIT License
    imagesloaded.js
        imagesLoaded PACKAGED v3.1.4
        MIT License
    imgliquid.js
        imgLiquid v0.9.944 / 03-05-2013
        Copyright (c) 2012 Alejandro Emparan (karacas) @krc_ale
        Dual licensed under the MIT and GPL licenses
        https://github.com/karacas/imgLiquid
    jflickrfeed.js
        Copyright (C) 2009 Joel Sutherland
        Licenced under the MIT license
        http://www.newmediacampaigns.com/page/jquery-flickr-plugin
    jquery.magnific-popup.js
        Magnific Popup - v1.0.1 - 2015-12-30
        Copyright (c) 2015 Dmitry Semenov
        http://dimsemenov.com/plugins/magnific-popup/
        Script is available under MIT license and will always be kept this way.
    mmenu-all.js
        jQuery mmenu v5.5.2
        Copyright (c) Fred Heusschen - www.frebsite.nl
        Licensed under the MIT license:
        http://en.wikipedia.org/wiki/MIT_License
    owl-carousel.js
        jQuery OwlCarousel v1.3.2
        Copyright (c) 2013 Bartosz Wojciechowski
        Licensed under MIT
    superfish.js
        jQuery Superfish Menu Plugin
        Copyright (c) 2013 Joel Birch
        Dual licensed under the MIT and GPL licenses:
        http://www.opensource.org/licenses/mit-license.php
        http://www.gnu.org/licenses/gpl.html
    uisearch.js
        uisearch.js v1.0.0
        Copyright 2013, Codrops - http://www.codrops.com
        Licensed under the MIT license.
        http://www.opensource.org/licenses/mit-license.php
    validate.js
        jQuery Validation Plugin 1.9.0
        Copyright (c) 2006 - 2011 Jörn Zaefferer
        Dual licensed under the MIT and GPL licenses:
        http://www.opensource.org/licenses/mit-license.php
        http://www.gnu.org/licenses/gpl.html


Thanks!
KOPASOFT
