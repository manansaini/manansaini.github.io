<?php

add_action( 'after_setup_theme', 'nictitate_lite_ii_after_setup_theme' );

function nictitate_lite_ii_after_setup_theme() {

    global $content_width;
    $content_width = 900;

    add_theme_support( 'title-tag' );    
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'loop-pagination' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption') );
    add_theme_support( 'post-formats', array( 'image', 'gallery', 'audio', 'video', 'quote', 'link' ) );

    load_theme_textdomain( 'nictitate-lite-ii', get_template_directory() . '/languages' );   

    register_nav_menus(array(
        'main-nav'   => esc_html__( 'Main Menu', 'nictitate-lite-ii' ),
        'mobile-nav' => esc_html__( 'Mobile Menu', 'nictitate-lite-ii' ),
    ));

    if ( is_admin() ) {
        add_action( 'admin_enqueue_scripts', 'nictitate_lite_ii_admin_enqueue_scripts' );
        add_action( 'kopa_admin_metabox_advanced_field', '__return_true' );
    } else {
        add_action( 'wp_enqueue_scripts', 'nictitate_lite_ii_enqueue_scripts' );
        add_filter( 'body_class', 'nictitate_lite_ii_set_body_class' );
        add_filter( 'post_class', 'nictitate_lite_ii_set_post_class' );        
        add_filter( 'post_thumbnail_html', 'nictitate_lite_ii_clean_image' );
        add_filter( 'image_send_to_editor', 'nictitate_lite_ii_clean_image' );        
    }
    
    // register image sizes.
    nictitate_lite_ii_register_new_image_sizes();
}

function nictitate_lite_ii_register_new_image_sizes() {    
    // blog.
    add_image_size( 'nictitate-blog-default', 852, 391, true );
    add_image_size( 'nictitate-blog-timeline', 418, 240, true );
    add_image_size( 'nictitate-blog-timeline-gallery', 418, 600, true );
    add_image_size( 'nictitate-blog-timeline-2', 880, 292, true );
    add_image_size( 'nictitate-blog-masonry', 264, 189, true );
    add_image_size( 'nictitate-single-default', 852, 391, true );
    add_image_size( 'nictitate-prev-next-post', 100, 72, true );
    add_image_size( 'nictitate-author-post', 117, 117, true );
    add_image_size( 'nictitate-related-post', 266, 183, true );

    //slide post type.
    add_image_size( 'nictitate-slider-carousel', 558, 396, true );
    
    //staff post type.
    add_image_size( 'nictitate-staff-list', 362, 315, true );

    //megamenu.
    add_image_size( 'nictitate-megamenu-single-post', 245, 176, true );
    add_image_size( 'nictitate-w-recent-post', 80, 80, true );

    // lightbox.
    add_image_size( 'nictitate-lightbox', 800, null, false );

}

if ( class_exists( 'Kopa_Framework' ) ) {   
 
    if ( class_exists( 'Kopa_Page_Builder' ) ) {
        add_filter( 'kopa_custom_use_page_layout_singular', 'nictitate_lite_ii_remove_custom_page_layout' );        
    }

    add_action( 'admin_init', 'nictitate_lite_ii_register_page_options' );
    
    add_filter( 'nictitate_lite_ii_get_sidebar_by_position', 'nictitate_lite_ii_set_sidebar_by_position', 10, 2 );
    
    add_action( 'kopa_admin_metabox_advanced_field', '__return_true' );    
    add_filter( 'kopa_layout_manager_settings', 'nictitate_lite_ii_register_layouts' );
    add_filter( 'kopa_custom_template_setting_id','nictitate_lite_ii_set_layout_setting_id' );
    add_filter( 'kopa_custom_layout_arguments', 'nictitate_lite_ii_edit_custom_layout_arguments' );    
    add_filter( 'kopa_sidebar_default', 'nictitate_lite_ii_set_sidebar_default' );
    add_filter( 'kopa_sidebar_default_attributes', 'nictitate_lite_ii_set_sidebar_default_attributes' );        

} else {

    add_action( 'widgets_init', 'nictitate_lite_ii_register_sidebar_default' );
    
}