<?php

function nictitate_lite_ii_register_sidebar_default() {
	$wrap     = nictitate_lite_ii_set_sidebar_default_attributes( array() );
	$sidebars = nictitate_lite_ii_set_sidebar_default( array() );

	if ( ! empty( $sidebars ) ) {
		foreach ( $sidebars as $slug => $sidebar ) {
			$tmp = $sidebar;
			$tmp['id']          = $slug;
			$tmp['name']        = $sidebar['name'];
			$tmp['description'] = $sidebar['description'];

			register_sidebar( $tmp );
		}
	}
}

function nictitate_lite_ii_set_sidebar_default( $sidebars ) {
	$sidebars['sb_right']    = array( 'name' => esc_html__( 'Right', 'nictitate-lite-ii' ), 'description' => '' );
	$sidebars['sb_footer_1'] = array( 'name' => esc_html__( 'Footer 1', 'nictitate-lite-ii' ), 'description' => '' );
	$sidebars['sb_footer_2'] = array( 'name' => esc_html__( 'Footer 2', 'nictitate-lite-ii' ), 'description' => '' );
	$sidebars['sb_footer_3'] = array( 'name' => esc_html__( 'Footer 3', 'nictitate-lite-ii' ), 'description' => '' );
	$sidebars['sb_footer_4'] = array( 'name' => esc_html__( 'Footer 4', 'nictitate-lite-ii' ), 'description' => '' );
	$sidebars['sb_footer_5'] = array( 'name' => esc_html__( 'Footer 5', 'nictitate-lite-ii' ), 'description' => '' );
	
	return $sidebars;
}

function nictitate_lite_ii_set_sidebar_default_attributes( $wrap ) {
	$wrap['before_widget'] = '<div id="%1$s" class="widget %2$s">';
	$wrap['after_widget']  = '</div>';
	$wrap['before_title']  = '<h3 class="widget-title nictitate_style_01">';
	$wrap['after_title']   = '</h3>';

	return $wrap;
}