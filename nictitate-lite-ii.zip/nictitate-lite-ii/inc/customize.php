<?php

function nictitate_lite_ii_customize_breadcrumb() {
    #BACKGROUND
    $image_bg = get_theme_mod( 'breadcrumb-background', '' );
    $page_header_css = '';
    if ( ! empty( $image_bg ) ) {
        $page_header_css .= sprintf( ".heading-page { background: url(%s) center top no-repeat; }", esc_url( $image_bg ) );
    }

    #MARGIN BOTTOM
    $margin_bottom = get_theme_mod( 'breadcrumb-bottom', '' );
    if ( ! empty( $margin_bottom ) && '80px' !== $margin_bottom ) {
        $page_header_css .= sprintf( '.heading-page {margin-bottom: %s;}', esc_attr( $margin_bottom ) );
    }
    if ( ! empty( $page_header_css ) ) {
        wp_add_inline_style( 'nictitate-lite-ii-style', $page_header_css );
    }
}

function nictitate_lite_ii_customize_breaking_news() {
    #BACKGROUND
    $image_bg = get_theme_mod( 'breaking-news-background', '' );
    $page_header_css = '';
    if ( ! empty( $image_bg ) ) {
        $page_header_css .= sprintf( ".k-widget-post-single-carousel {background: url(%s) center top no-repeat;}", esc_url( $image_bg ) );
    }
    if ( ! empty( $page_header_css ) ) {
        wp_add_inline_style( 'nictitate-lite-ii-style', $page_header_css );
    }
}

function nictitate_lite_ii_customize_css() {
    #CUSTOM CSS
    $custom_css = get_theme_mod( 'custom-css', '' );
    if ( ! empty( $custom_css ) ) {
        wp_add_inline_style( 'nictitate-lite-ii-style', $custom_css );
    }
}