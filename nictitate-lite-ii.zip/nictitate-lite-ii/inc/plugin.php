<?php
require get_template_directory() . '/addons/TGMPluginActivation.class.php';

add_action( 'tgmpa_register', 'nictitate_lite_ii_register_required_plugins' );

function nictitate_lite_ii_register_required_plugins() {
    $plugins = array(            
        array(
            'name'               => 'Kopa Framework',
            'slug'               => 'kopatheme',
            'required'           => true,
            'force_activation'   => false,
            'force_deactivation' => false,
            'external_url'       => '',
        ),
        array(
            'name'               => 'Kopa Page Builder',
            'slug'               => 'kopa-page-builder',
            'required'           => false,
            'force_activation'   => false,
            'force_deactivation' => false,
            'external_url'       => '',
        ),
        array(
            'name'               => 'Nictitate Lite II Toolkit',
            'slug'               => 'nictitate-lite-ii-toolkit',
            'required'           => false,
            'version'            => '1.0.2',
            'force_activation'   => false,
            'force_deactivation' => false,
            'external_url'       => ''
        ),
    );
    $config = array(        
        'has_notices'  => true,
        'is_automatic' => false
    );
    
    tgmpa( $plugins, $config );    
}
