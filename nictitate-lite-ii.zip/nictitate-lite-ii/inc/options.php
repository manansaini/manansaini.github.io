<?php
require_once( get_template_directory() . '/inc/options/header.php' );
require_once( get_template_directory() . '/inc/options/breadcrumb.php' );
require_once( get_template_directory() . '/inc/options/breaking-news.php' );
require_once( get_template_directory() . '/inc/options/footer.php' );
require_once( get_template_directory() . '/inc/options/blog.php' );
require_once( get_template_directory() . '/inc/options/single.php' );
require_once( get_template_directory() . '/inc/options/portfolio.php' );
require_once( get_template_directory() . '/inc/options/social-links.php' );
require_once( get_template_directory() . '/inc/options/css.php' );
