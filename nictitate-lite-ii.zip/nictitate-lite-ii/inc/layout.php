<?php

function nictitate_lite_ii_get_template_setting( $default = null ) {
    $setting = array( 'layout_id' => '', 'sidebars'  => array() );

    if ( function_exists( 'kopa_get_template_setting' ) ) {       
        $setting = kopa_get_template_setting();
    }    

    if ( empty( $setting['layout_id'] ) ) {
        if ( is_404() ) {
            $setting['layout_id'] = 'default';
        } elseif ( is_search() ) {
            $setting['layout_id'] = 'default';
        } elseif ( is_home() ) {
            $setting['layout_id'] = 'blog-default';
        } elseif ( is_front_page() ) {
            $setting['layout_id'] = 'static-page';
        } elseif ( is_singular() ) {
            if ( is_page() ) {
                $setting['layout_id'] = 'static-page';
            } elseif ( is_singular( 'post' ) ) {
                $setting['layout_id'] = 'single-default';
            } elseif ( is_singular( 'portfolio' ) ) {                
                $setting['layout_id'] = 'portfolio-single-one-column';
            } else {
                $setting['layout_id'] = 'single-default';
            }
        } elseif ( is_archive() ) {
            $setting['layout_id'] = 'blog-default';
            if ( is_post_type_archive( 'portfolio' ) || is_tax( 'portfolio_tag' )  || is_tax( 'portfolio_project' ) ) {
                $setting['layout_id'] = 'portfolio-archive';
            }
        }
    }

    return $setting['layout_id'];
}

if ( class_exists( 'Kopa_Framework' ) ) {   
    function nictitate_lite_ii_register_layouts( $options ) {
        $positions = nictitate_lite_ii_get_positions();
        $sidebars  = nictitate_lite_ii_assign_sidebar_to_position();

        $blog_default = array(
            'title'     => esc_html__( 'Blog default', 'nictitate-lite-ii' ),
            'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/blog-default.png',
            'positions' => array(
                'pos_right',
                'pos_footer_1',
                'pos_footer_2',
                'pos_footer_3',
                'pos_footer_4',
                'pos_footer_5',
            )
        );

        $blog_masonry = array(
            'title'     => esc_html__( 'Blog masonry', 'nictitate-lite-ii' ),
            'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/blog-masonry.png',
            'positions' => array(
                'pos_footer_1',
                'pos_footer_2',
                'pos_footer_3',
                'pos_footer_4',
                'pos_footer_5',
            )
        );

        $options['blog-layout']['positions']                              = $positions;
        $options['blog-layout']['layouts']['blog-default']                = $blog_default;
        $options['blog-layout']['layouts']['blog-masonry']                = $blog_masonry;
        $options['blog-layout']['default']['layout_id']                   = 'blog-default';
        $options['blog-layout']['default']['sidebars']['blog-default']    = $sidebars;
        $options['blog-layout']['default']['sidebars']['blog-masonry']    = $sidebars;

        $single_default = array(
            'title'     => esc_html__( 'Single', 'nictitate-lite-ii' ),
            'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/single.png',
            'positions' => array(
                'pos_right',
                'pos_footer_1',
                'pos_footer_2',
                'pos_footer_3',
                'pos_footer_4',
                'pos_footer_5',
            )
        );

        $options['post-layout']['positions']                             = $positions;
        $options['post-layout']['layouts']['single-default']             = $single_default;
        $options['post-layout']['default']['layout_id']                  = 'single-default';
        $options['post-layout']['default']['sidebars']['single-default'] = $sidebars;

        #PAGE
        $page_default = array(
            'title'     => esc_html__( 'Static page', 'nictitate-lite-ii' ),
            'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/static-page.png',
            'positions' => array(
                'pos_footer_1',
                'pos_footer_2',
                'pos_footer_3',
                'pos_footer_4',
                'pos_footer_5',
            )
        );

        $options['page-layout']['positions']                      = $positions;
        $options['page-layout']['layouts']['default']             = $page_default;
        $options['page-layout']['default']['layout_id']           = 'default';
        $options['page-layout']['default']['sidebars']['default'] = $sidebars;

        #FRONT PAGE
        $options['frontpage-layout']['positions']                      = $positions;
        $options['frontpage-layout']['layouts']['default']             = $page_default;
        $options['frontpage-layout']['default']['layout_id']           = 'default';
        $options['frontpage-layout']['default']['sidebars']['default'] = $sidebars;

        #SEARCH
        $search_default = array(
            'title'     => esc_html__( 'Search layout', 'nictitate-lite-ii' ),
            'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/blog-default.png',
            'positions' => array(
                'pos_right',
                'pos_footer_1',
                'pos_footer_2',
                'pos_footer_3',
                'pos_footer_4',
                'pos_footer_5',
            )
        );

        $options['search-layout']['positions']                      = $positions;
        $options['search-layout']['layouts']['default']             = $search_default;
        $options['search-layout']['default']['layout_id']           = 'default';
        $options['search-layout']['default']['sidebars']['default'] = $sidebars;

        #6: Error 404
        $error_404_default = array(
            'title'     => esc_html__('Error page - 404', 'nictitate-lite-ii'),
            'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/error-404.png',
            'positions' => array(
                'pos_footer_1',
                'pos_footer_2',
                'pos_footer_3',
                'pos_footer_4',
                'pos_footer_5',
            ));
        $options['error404-layout']['positions']                      = $positions;
        $options['error404-layout']['layouts']['default']             = $error_404_default;
        $options['error404-layout']['default']['layout_id']           = 'default';
        $options['error404-layout']['default']['sidebars']['default'] = $sidebars;

        #8: Portfolio
        if ( class_exists( 'Nictitate_Lite_II_Toolkit' ) ) {
            #Archive
            $layout = array(
                'title'     => esc_html__( 'Portfolio Archive', 'nictitate-lite-ii' ),
                'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/portfolio-archive.png',
                'positions' => array(
                    'pos_footer_1',
                    'pos_footer_2',
                    'pos_footer_3',
                    'pos_footer_4',
                    'pos_footer_5',)
            );

            $options[] = array(
                'title'   => esc_html__( 'Portfolio Archive', 'nictitate-lite-ii' ),
                'type' 	  => 'title',
                'id' 	  => 'portfolio-archive-title'
            );

            $options['portfolio-archive'] = array(
                'title'     =>  esc_html__( 'Portfolio Archive',  'nictitate-lite-ii' ),
                'type'      => 'layout_manager',
                'id'        => 'portfolio-archive',
                'positions' => $positions,
                'layouts'   => array(
                    'portfolio-archive' => $layout,
                ),
                'default' => array(
                    'layout_id' => 'portfolio-archive',
                    'sidebars'  => array(
                        'portfolio-archive' => $sidebars,
                    ),
                ),
            );

            #Single
            $layout_single_two_columns = array(
                'title'     => esc_html__( 'Portfolio Single Two Columns', 'nictitate-lite-ii' ),
                'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/portfolio-single-two-columns.png',
                'positions' => array(
                    'pos_footer_1',
                    'pos_footer_2',
                    'pos_footer_3',
                    'pos_footer_4',
                    'pos_footer_5'));

            $layout_single_one_column = array(
                'title'     => esc_html__( 'Portfolio Single One Column', 'nictitate-lite-ii' ),
                'preview'   => get_template_directory_uri() . '/inc/assets/images/layouts/portfolio-single-one-column.png',
                'positions' => array(
                    'pos_footer_1',
                    'pos_footer_2',
                    'pos_footer_3',
                    'pos_footer_4',
                    'pos_footer_5'));

            $options[] = array(
                'title'   => esc_html__( 'Portfolio Single', 'nictitate-lite-ii' ),
                'type' 	  => 'title',
                'id' 	  => 'portfolio-single-title'
            );

            $options[] = array(
                'title'     =>  esc_html__( 'Portfolio Single',  'nictitate-lite-ii' ),
                'type'      => 'layout_manager',
                'id'        => 'portfolio-single',
                'positions' => $positions,
                'layouts'   => array(
                    'portfolio-single-one-column'  => $layout_single_one_column,
                    'portfolio-single-two-columns' => $layout_single_two_columns
                ),
                'default' => array(
                    'layout_id' => 'portfolio-single-one-column',
                    'sidebars'  => array(
                        'portfolio-single-one-column'  => $sidebars,
                        'portfolio-single-two-columns' => $sidebars
                    ),
                ),
            );
        }

        return apply_filters( 'nictitate_lite_ii_register_layouts', $options );
    }

    function nictitate_lite_ii_get_positions() {
        $positions = array(
            'pos_right'    => esc_html__( 'The right position', 'nictitate-lite-ii' ),
            'pos_footer_1' => esc_html__( 'Footer 1', 'nictitate-lite-ii' ),
            'pos_footer_2' => esc_html__( 'Footer 2', 'nictitate-lite-ii' ),
            'pos_footer_3' => esc_html__( 'Footer 3', 'nictitate-lite-ii' ),
            'pos_footer_4' => esc_html__( 'Footer 4', 'nictitate-lite-ii' ),
            'pos_footer_5' => esc_html__( 'Footer 5', 'nictitate-lite-ii' )
        );

        return apply_filters( 'nictitate_lite_ii_get_positions', $positions );
    }

    function nictitate_lite_ii_assign_sidebar_to_position() {
        $sidebar = array(
            'pos_right'    => 'sb_right',
            'pos_footer_1' => 'sb_footer_1',
            'pos_footer_2' => 'sb_footer_2',
            'pos_footer_3' => 'sb_footer_3',
            'pos_footer_4' => 'sb_footer_4',
            'pos_footer_5' => 'sb_footer_5',
        );

        return apply_filters( 'nictitate_lite_ii_get_sidebars', $sidebar );
    }

    function nictitate_lite_ii_set_sidebar_by_position( $sidebar, $position ) {
        $nictitate_lite_ii_setting = kopa_get_template_setting();
        if ( isset( $nictitate_lite_ii_setting['sidebars'][$position] ) ) {
            $sidebar = $nictitate_lite_ii_setting['sidebars'][$position];
        }

        return $sidebar;
    }

    function nictitate_lite_ii_edit_custom_layout_arguments( $args ) {
        $args[] = array(
            'screen'   => 'portfolio_project',
            'taxonomy' => true,
            'layout'   => 'portfolio-archive',
        );

        $args[] = array(
            'screen'   => 'portfolio_tag',
            'taxonomy' => true,
            'layout'   => 'portfolio-archive',
        );
            
        $args[] = array(
            'screen'   => 'portfolio',
            'taxonomy' => false,
            'layout'   => 'portfolio-single',
        );        

        return $args;
    }

    function nictitate_lite_ii_set_layout_setting_id( $setting_id ) {
        if ( is_singular( 'portfolio' ) ) {
            $setting_id = 'portfolio-single';
        } elseif ( is_post_type_archive( 'portfolio' ) || is_tax( 'portfolio_tag' )  || is_tax( 'portfolio_project' ) ) {
            $setting_id = 'portfolio-archive';
        }
        
        return $setting_id;
    }

    function nictitate_lite_ii_remove_custom_page_layout( $status ) {
        global $post;
        
        if( !empty( $post ) ){
            if( 'page' === $post->post_type ){
                $status = false;
            }
        }

        return $status;
    }

}