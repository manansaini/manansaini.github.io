<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_blog');

function nictitate_lite_ii_init_options_blog( $options ) {

	$options[] = array(
		'title' => esc_html__( 'Blog', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-blog'
		);

	$options[]=array(
		'title' => esc_html__( 'Featured image','nictitate-lite-ii' ),
		'type'	=>'groupstart',
		'id'	=>'grFeatureImg'
		);

	$options[] = array(
		'title'   => esc_html__( 'If no post featured image, then', 'nictitate-lite-ii' ),
		'type'    => 'select',
		'default' => 'show_placeholdit',
		'options' => array(
			'show_placeholdit' => esc_html__( 'Show placeholdit image', 'nictitate-lite-ii'  ),
			'no_show'          => esc_html__( 'No show', 'nictitate-lite-ii'  ),
			),
		'id'    => 'blog_featured_img',
		'desc'  => '',
		);
	
	$options[] = array(
		'id'      =>'grFeatureImg',
		'type'	  =>'groupend'
		);

	$options[]=array(
		'title' => esc_html__( 'Excerpt','nictitate-lite-ii' ),
		'type'	=>'groupstart',
		'id'	=>'grExcerpt'
		);

	$options[] = array(
		'title'   => esc_html__( 'Number words of excerpt to show', 'nictitate-lite-ii' ),
		'type'    => 'number',
		'id'      => 'blog_excerpt_length',
		'default' => 10,
		'desc'    => ''
		);

	$options[] = array(
		'id'      =>'grExcerpt',
		'type'	  =>'groupend'
		);

	$options[]=array(
		'title' => esc_html__( 'Metadata','nictitate-lite-ii' ),
		'type'	=>'groupstart',
		'id'	=>'grMetadata'
		);

	$options[] = array(
		'label'   => esc_html__( 'Show date', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_date',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'label'   => esc_html__( 'Show count comment', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_count_comment',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'label'   => esc_html__( 'Show author', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_author',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'label'   => esc_html__( 'Show category', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_category',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'label'   => esc_html__( 'Show like', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_likes',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'label'   => esc_html__( 'Show social sharing', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_social_sharing',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'label'   => esc_html__( 'Show read more', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'blog_read_more',
		'default' => 1,
		'desc'    => ''
		);

	$options[] = array(
		'id'      =>'grMetadata',
		'type'	  =>'groupend'
		);

	return $options;
}
