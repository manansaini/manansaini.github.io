<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_social_share' );

function nictitate_lite_ii_init_options_social_share( $options ) {

	$options[] = array(
		'title' => esc_html__( 'Social Links', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-social-share'
	);

        $socials = nictitate_lite_ii_get_socials();
        if ( $socials ) {
            foreach ( $socials as $v ) {
                if ( 'rss' == $v['id'] ) {
                    $options[] = array(
                        'title' => esc_html($v['title']),
                        'type'  => 'text',
                        'id'    => 'social_share_' . esc_attr($v['id']),
                        'std'   => '',
                        'desc'  => esc_html__( 'Display link share for ', 'nictitate-lite-ii' ) . esc_html($v['title']) . wp_kses_post( 'Enter <code>HIDE</code> to hide this option. Default is <code>', 'nictitate-lite-ii' ) . esc_attr( get_bloginfo( 'rss2_url' ) ) . '</code>',
                    );
                } else {
                    $options[] = array(
                        'title' => esc_html( $v['title'] ),
                        'type'  => 'text',
                        'id'    => 'social_share_' . esc_attr( $v['id'] ),
                        'std'   => '',
                        'desc'  => esc_html__( 'Display link share for ', 'nictitate-lite-ii' ) . esc_html( $v['title']),
                    );
                }
            }
        }

	return $options;
}