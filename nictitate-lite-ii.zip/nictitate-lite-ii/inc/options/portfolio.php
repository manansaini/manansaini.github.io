<?php

if ( class_exists( 'Nictitate_Lite_II_Toolkit' ) ){

	add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_portfolio' );

	function nictitate_lite_ii_init_options_portfolio( $options ) {

		$options[] = array(
            'title' => esc_html__( 'Portfolio', 'nictitate-lite-ii' ),
            'type'  => 'title',    
            'id'    => 'nictitate-lite-ii-portfolio'          
        );            

        $options[] = array(
            'title' => esc_html__( 'Archive', 'nictitate-lite-ii' ),
            'type'  => 'groupstart'
        );
        
        $options[] = array(
            'title'   => esc_html__( 'Project per page', 'nictitate-lite-ii' ),
            'type' 	  => 'text',
            'id' 	  => 'portfolio-archive-project-per-page',
            'default' => 9
        );
        $options[] = array(
            'title'   => esc_html__( 'Archive title', 'nictitate-lite-ii' ),
            'type' 	  => 'text',
            'id' 	  => 'portfolio-archive-title',
            'default' => ''
        );
        $options[] = array(
            'title'   => esc_html__( 'Archive description', 'nictitate-lite-ii' ),
            'type' 	  => 'textarea',
            'id' 	  => 'portfolio-archive-description',
            'default' => ''
        );
        $options[] = array(
            'label'   => esc_html__( 'Project metadata', 'nictitate-lite-ii' ),
            'type' 	  => 'checkbox',
            'id' 	  => 'portfolio-archive-show-project',
            'default' => 1,
            'desc'    => esc_html__( 'Check this option to display.', 'nictitate-lite-ii')
        );
                
        $options[] = array(
            'type'  => 'groupend'                
        );

		return $options;
	}

}