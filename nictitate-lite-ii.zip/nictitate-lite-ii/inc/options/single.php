<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_single' );

function nictitate_lite_ii_init_options_single( $options ) {

	$options[] = array(
		'title' => esc_html__( 'Single', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-single'
	);

	$options[]=array(
		'title' => esc_html__( 'Metadata','nictitate-lite-ii' ),
		'type'	=> 'groupstart',
		'id'	=> 'grMetadata'
	);

	$options[] = array(
		'label'   => esc_html__( 'Show date', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_date',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show count comment', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_count_comment',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show author', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_author',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show category', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_category',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show likes', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_likes',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show previous next post', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_prev_next',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show tags', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_tags',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show share social', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_share',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'label'   => esc_html__( 'Show about author', 'nictitate-lite-ii' ),
		'type'    => 'checkbox',
		'id'      => 'single_about_author',
		'default' => 1,
		'desc'    => ''
	);

	$options[] = array(
		'id'   => 'grMetadata',
		'type' => 'groupend'
	);

	$options[]=array(
		'title' => esc_html__( 'Related post','nictitate-lite-ii' ),
		'type'	=> 'groupstart',
		'id'	=> 'grRelatedPostStyle'
	);

	$options[] = array(
		'title'   => esc_html__( 'Get by', 'nictitate-lite-ii' ),
		'type'    => 'select',
		'default' => 'category',
		'options' => array(
			'category' => esc_html__( 'Category', 'nictitate-lite-ii' ),
			'post_tag' => esc_html__( 'Tag', 'nictitate-lite-ii' ),
			),
		'id'    => 'single_relate_get_by',
		'desc'  => ''
	);

	$options[] = array(
		'title'   => esc_html__( 'Number of posts', 'nictitate-lite-ii' ),
		'type'    => 'number',
		'id'      => 'single_relate_limit',
		'default' => 3,
		'desc'    => esc_html__( 'Enter 0 to hide related post', 'nictitate-lite-ii' )
	);
	
	$options[] = array(
		'id'   => 'grRelatedPostStyle',
		'type' => 'groupend'
	);

	return $options;
}
