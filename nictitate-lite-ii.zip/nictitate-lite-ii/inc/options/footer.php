<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_footer' );

function nictitate_lite_ii_init_options_footer( $options ) {

	$options[] = array(
		'title' => esc_html__( 'Footer', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-footer'
	);

        $options[] = array(
            'label'   => esc_html__( 'Show sidebars on footer', 'nictitate-lite-ii' ),
            'type'    => 'checkbox',
            'id'      => 'footer_use_sidebar',
            'default' => 1,
            'folds'   => 1
        );
        $options[] = array(
            'title'    => esc_html__( 'Copyright', 'nictitate-lite-ii' ),
            'type'     => 'textarea',
            'id'       => 'copyright',
            'validate' => false
        );
        $options[] = array(
            'label'   => esc_html__( 'Show socials on footer', 'nictitate-lite-ii' ),
            'type'    => 'checkbox',
            'id'      => 'footer_use_social',
            'default' => 1,
            'folds'   => 1
        );

    return apply_filters( 'nictitate_lite_ii_set_footer_option', $options );
}