<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_custom_css' );

function nictitate_lite_ii_init_options_custom_css( $options ) {
	$options[] = array(
		'title' => esc_html__( 'Custom CSS', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-custom-css'
	);
        $options[] = array(
            'title'   => esc_html__( 'Custom CSS', 'nictitate-lite-ii' ),
            'type'    => 'textarea',
            'id'      => 'custom-css',
            'default' => '',
            'desc'    => esc_html__( 'Enter custom CSS.', 'nictitate-lite-ii' )
        );

	return apply_filters( 'nictitate_lite_ii_set_custom_css', $options );
}