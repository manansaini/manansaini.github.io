<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_header' );

function nictitate_lite_ii_init_options_header( $options ) {
	$options[] = array(
		'title' => esc_html__( 'Header', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-header'
	);
        $header_styles = nictitate_lite_ii_get_header_style();

        $options[] = array(
            'title' => esc_html__( 'Choose header style', 'nictitate-lite-ii' ),
            'type'  => 'select',
            'options' => $header_styles,
            'id'    => 'header-style',
            'desc'  => esc_html__( 'Choose header style.', 'nictitate-lite-ii' )
        );
		$options[] = array(
			'title' => esc_html__( 'Logo', 'nictitate-lite-ii' ),
			'type'  => 'upload',
			'id'    => 'logo',
			'desc'  => esc_html__( 'Upload your logo.', 'nictitate-lite-ii' )
		);
        $options[] = array(
            'title' => esc_html__( 'Logo in mobile', 'nictitate-lite-ii' ),
            'type'  => 'upload',
            'id'    => 'logo-mobile',
            'desc'  => esc_html__( 'Upload your logo for mobile.', 'nictitate-lite-ii' )
        );
        $options[] = array(
            'title' => esc_html__( 'Phone', 'nictitate-lite-ii' ),
            'type'  => 'text',
            'id'    => 'header-phone',
            'std'   => ''
        );
        $options[] = array(
            'title' => esc_html__( 'Email', 'nictitate-lite-ii' ),
            'type'  => 'text',
            'id'    => 'header-email',
            'std'   => '',
            'desc'  => esc_html__( 'Only show in Header 1 & Header 4', 'nictitate-lite-ii' )
        );
        $options[] = array(
            'title' => esc_html__( 'Open text', 'nictitate-lite-ii' ),
            'type'  => 'text',
            'id'    => 'header-open-text',
            'std'   => ''
        );
        $options[] = array(
            'title' => esc_html__( 'Close text', 'nictitate-lite-ii' ),
            'type'  => 'text',
            'id'    => 'header-close-text',
            'std'   => '',
            'desc'  => esc_html__( 'Only show in Header 1 & Header 4', 'nictitate-lite-ii' )
        );
        $options[] = array(
            'label'   => esc_html__( 'Show socials on navigation', 'nictitate-lite-ii' ),
            'type'    => 'checkbox',
            'id'      => 'header-show-social',
            'default' => 1
        );
        $options[] = array(
            'label'   => esc_html__( 'Show search form', 'nictitate-lite-ii' ),
            'type'    => 'checkbox',
            'id'      => 'header-show-search',
            'default' => 1
        );
        $options[] = array(
            'title' => esc_html__( 'Address', 'nictitate-lite-ii' ),
            'type'  => 'text',
            'id'    => 'header-address',
            'std'   => '',
            'desc'  => esc_html__( 'Only show in Header 4', 'nictitate-lite-ii' )
        );


	return apply_filters( 'nictitate_lite_ii_set_header_option', $options );
}