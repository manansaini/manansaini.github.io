<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_breadcrumb' );

function nictitate_lite_ii_init_options_breadcrumb( $options ) {
	$options[] = array(
		'title' => esc_html__( 'Breadcrumb', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-breadcrumb'
	);
        $options[] = array(
            'label'   => esc_html__( 'Show breadcrumb', 'nictitate-lite-ii' ),
            'type'    => 'checkbox',
            'id'      => 'is-enable-breadcrumb',
            'default' => 1,
            'desc'    => esc_html__( 'Check this option to display.', 'nictitate-lite-ii' ),
            'folds'   => 1
        );
        $options[] = array(
            'title' => esc_html__( 'Background', 'nictitate-lite-ii' ),
            'type'  => 'upload',
            'id'    => 'breadcrumb-background',
            'desc'  => esc_html__( 'Upload background for breadcrumb.', 'nictitate-lite-ii' ),
            'fold'  => 'is-enable-breadcrumb'
        );
        $options[] = array(
            'title'   => esc_html__( 'Margin bottom', 'nictitate-lite-ii' ),
            'type'    => 'text',
            'id'      => 'breadcrumb-bottom',
            'default' => '80px',
            'desc'    => esc_html__( 'Default is 80px.', 'nictitate-lite-ii' ),
            'fold'    => 'is-enable-breadcrumb'
        );

	return apply_filters( 'nictitate_lite_ii_set_breadcrumb_option', $options );
}