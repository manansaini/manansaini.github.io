<?php

add_filter( 'kopa_theme_options_settings', 'nictitate_lite_ii_init_options_breaking_news' );

function nictitate_lite_ii_init_options_breaking_news( $options ) {
	$options[] = array(
		'title' => esc_html__( 'Breaking News', 'nictitate-lite-ii' ),
		'type'  => 'title',
		'id'	=> 'nictitate-lite-ii-breaking-news'
	);
        $options[] = array(
            'label'   => esc_html__( 'Show breaking news ( Only working with layout "blog timeline")', 'nictitate-lite-ii' ),
            'type'    => 'checkbox',
            'id'      => 'is-enable-breaking-news',
            'default' => 1,
            'desc'    => esc_html__( 'Check this option to display.', 'nictitate-lite-ii' ),
            'folds'   => 1
        );
        $options[] = array(
            'title'   => esc_html__( 'Title', 'nictitate-lite-ii' ),
            'type'    => 'text',
            'id'      => 'breaking-news-title',
            'default' => esc_html__( 'Breaking News', 'nictitate-lite-ii' ),
            'fold'    => 'is-enable-breaking-news'
        );
        $options[] = array(
            'title' => esc_html__( 'Background', 'nictitate-lite-ii' ),
            'type'  => 'upload',
            'id'    => 'breaking-news-background',
            'desc'  => esc_html__('Upload background for breaking news.', 'nictitate-lite-ii' ),
            'fold'  => 'is-enable-breaking-news'
        );
        $terms = get_terms( 'category' );
        $arr_cat = array(
            '' => esc_html__( '--- Select ---', 'nictitate-lite-ii' )
            );
        foreach ( $terms as $v ) 
            $arr_cat[$v->term_id] = $v->name . '(' . $v->count . ')';

        $options[] = array(
            'title'   => esc_html__( 'Headline categories', 'nictitate-lite-ii' ),
            'type'    => 'multiselect',
            'id'      => 'breaking-news-cats',
            'default' => '',
            'options' => $arr_cat,
            'fold'    => 'is-enable-breaking-news'
        );
        $options[] = array(
            'title'   => esc_html__( 'Number of posts', 'nictitate-lite-ii' ),
            'type'    => 'number',
            'id'      => 'breaking-news-limit',
            'default' => 5,
            'fold'    => 'is-enable-breaking-news'
        );

	return apply_filters( 'nictitate_lite_ii_set_breaking_news_option', $options );
}