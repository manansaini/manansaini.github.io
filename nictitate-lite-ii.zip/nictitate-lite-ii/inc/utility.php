<?php

function nictitate_lite_ii_set_body_class( $classes ) {
    // LAYOUT STYLE.
    $layout_id = nictitate_lite_ii_get_template_setting();    
    switch ( $layout_id ) {
        case 'blog-default': 
            array_push( $classes, 'blog-default' );
            break;
        case 'blog-timeline':
        case 'blog-timeline-2':
            array_push( $classes, 'blog-timeline-page' );
            break;
        case 'blog-masonry':
            array_push( $classes, 'blog-masonry-page' );            
            break;
        case 'single-default':
            array_push( $classes, 'single-page' );            
            break;            
    }

    // HEADER STYLE.
    $header_style = get_theme_mod( 'header-style', 'style-1' );
    array_push( $classes, sprintf( 'nictitate-header-%s', $header_style ) );

    return $classes;
}

function nictitate_lite_ii_set_post_class( $classes ) {
    array_push( $classes, 'nictitate-article' );

    return $classes;
}

function nictitate_lite_ii_clean_image( $html ) {   
   return preg_replace( '/(width|height)="\d*"\s/', '', $html );
}

function nictitate_lite_ii_get_allowed_tags() {
    $allowed_tag                              = wp_kses_allowed_html( 'post' );
    
    $allowed_tag['div']['data-place']         = array();
    $allowed_tag['div']['data-latitude']      = array();
    $allowed_tag['div']['data-longitude']     = array();
    $allowed_tag['div']['data-longitude']     = array();
    $allowed_tag['div']['data-val']           = array();
    
    $allowed_tag['iframe']['src']             = array();
    $allowed_tag['iframe']['height']          = array();
    $allowed_tag['iframe']['width']           = array();
    $allowed_tag['iframe']['frameborder']     = array();
    $allowed_tag['iframe']['allowfullscreen'] = array();
    
    $allowed_tag['input']['class']            = array();
    $allowed_tag['input']['id']               = array();
    $allowed_tag['input']['name']             = array();
    $allowed_tag['input']['value']            = array();
    $allowed_tag['input']['type']             = array();
    $allowed_tag['input']['checked']          = array();
    
    $allowed_tag['select']['class']           = array();
    $allowed_tag['select']['id']              = array();
    $allowed_tag['select']['name']            = array();
    $allowed_tag['select']['value']           = array();
    $allowed_tag['select']['type']            = array();
    
    $allowed_tag['option']['selected']        = array();
    
    $allowed_tag['style']['types']            = array();

    $microdata_tags = array( 'div', 'section', 'article', 'a', 'span', 'img', 'time', 'figure' );
    foreach ( $microdata_tags as $tag ) {
        $allowed_tag[ $tag ]['itemscope'] = array();
        $allowed_tag[ $tag ]['itemtype']  = array();
        $allowed_tag[ $tag ]['itemprop']  = array();
    }

    $allowed_tag['a']['data-val'] = array();

    return apply_filters( 'nictitate_lite_ii_get_allowed_tags', $allowed_tag );
}

function nictitate_lite_ii_get_socials() {
    $socials = array(
        array(
            'title' => esc_html__( 'Rss', 'nictitate-lite-ii' ),
            'id'    => 'rss',
            'icon'  => 'fa fa-rss',
        ),
        array(
            'title' => esc_html__( 'Facebook', 'nictitate-lite-ii' ),
            'id'    => 'facebook',
            'icon'  => 'fa fa-facebook',
        ),
        array(
            'title' => esc_html__( 'Twitter', 'nictitate-lite-ii' ),
            'id'    => 'twitter',
            'icon'  => 'fa fa-twitter',
        ),
        array(
            'title' => esc_html__( 'Google plus', 'nictitate-lite-ii' ),
            'id'    => 'google-plus',
            'icon'  => 'fa fa-google-plus',
        ),
        array(
            'title' => esc_html__( 'Pinterest', 'nictitate-lite-ii' ),
            'id'    => 'pinterest',
            'icon'  => 'fa fa-pinterest',
        ),
        array(
            'title' => esc_html__( 'Instagram', 'nictitate-lite-ii' ),
            'id'    => 'instagram',
            'icon'  => 'fa fa-instagram',
        ),
        array(
            'title' => esc_html__( 'Dribbble', 'nictitate-lite-ii' ),
            'id'    => 'dribbble',
            'icon'  => 'fa fa-dribbble',
        ),
        array(
            'title' => esc_html__( 'Linkedin', 'nictitate-lite-ii' ),
            'id'    => 'linkedin',
            'icon'  => 'fa fa-linkedin',
        ),
        array(
            'title' => esc_html__( 'Github', 'nictitate-lite-ii' ),
            'id'    => 'github',
            'icon'  => 'fa fa-github',
        ),
        array(
            'title' => esc_html__( 'Wordpress', 'nictitate-lite-ii' ),
            'id'    => 'wordpress',
            'icon'  => 'fa fa-wordpress',
        ),
    );

    return apply_filters( 'nictitate_lite_ii_get_socials', $socials );
}

function nictitate_lite_ii_get_opacity( $opacity ) {
    $css = sprintf( '-ms-filter: "progid:DXImageTransform.Microsoft.Alpha(Opacity=%d)";', $opacity * 100 );
    $css .= sprintf( 'filter: alpha(opacity=%d);', $opacity * 100 );
    $css .= sprintf( '-moz-opacity: %s;', $opacity );
    $css .= sprintf( '-khtml-opacity: %s;', $opacity );
    $css .= sprintf( 'opacity: %s;', $opacity );

    return $css;
}

function nictitate_lite_ii_get_rgba( $color, $opacity = false ) {
    $default = 'rgb(0,0,0)';

    if ( empty( $color ) ) {
        return $default;
    }

    if ( '#' === $color[0] ) {
        $color = substr( $color, 1 );
    }

    if ( 6 === strlen( $color ) ) {
        $hex = array( $color[0] . $color[1], $color[2] . $color[3], $color[4] . $color[5] );
    } elseif ( 3 === strlen( $color ) ) {
        $hex = array( $color[0] . $color[0], $color[1] . $color[1], $color[2] . $color[2] );
    } else {
        return $default;
    }

    $rgb = array_map( 'hexdec', $hex );

    if ( $opacity ) {
        if ( abs( $opacity ) > 1 ) {
            $opacity = 1.0;
        }

        $output = 'rgba(' . implode( ',', $rgb ) . ',' . $opacity . ')';
    } else {
        $output = 'rgb(' . implode( ',', $rgb ) . ')';
    }

    return $output;
}

function nictitate_lite_ii_get_header_style( $is_get_all = false ) {
    $styles = array();
    $styles['style-1'] = esc_html__( 'Header 1', 'nictitate-lite-ii' );
    $styles['style-4'] = esc_html__( 'Header 4', 'nictitate-lite-ii' );

    return apply_filters( 'nictitate_lite_ii_get_header_style', $styles );
}

function nictitate_lite_ii_set_excerpt_length( $length ) {
    if( isset( $GLOBALS['nictitate_lite_ii_excerpt_length'] ) ){
        $length = (int) $GLOBALS['nictitate_lite_ii_excerpt_length'];
    }

    return $length;
}

function nictitate_lite_ii_get_image_src ( $post_id, $size='full' ) {    
    $image = wp_get_attachment_image_src( $post_id, $size );

    return isset( $image[0] ) ? esc_url( $image[0] ) : '';
}
