<?php

function nictitate_lite_ii_register_page_options() {	
	$args = array(
        'id'          => 'nictitate-lite-ii-metabox-advance-options',
        'title'       => esc_html__( 'Advance options', 'nictitate-lite-ii' ),
        'desc'        => '',
        'pages'       => array( 'page', 'post' ),
        'context'     => 'normal',
        'priority'    => 'low',
        'fields'      => array(      
            array(
				'title'   => esc_html__( 'Is hide breadcrumb', 'nictitate-lite-ii' ),						
				'type'    => 'checkbox',
				'default' => 0,
				'id'      => 'nictitate_lite_ii_is_hide_breadcrumb',
            ),
            array(
                'title'   => esc_html__( 'Is hide footer socials', 'nictitate-lite-ii' ),                     
                'type'    => 'checkbox',
                'default' => 0,
                'id'      => 'nictitate_lite_ii_is_hide_footer_socials',
            ),		          
        )
    );

    kopa_register_metabox( $args );	  	
}