<?php

function nictitate_lite_ii_enqueue_scripts() {    
    $dir = get_template_directory_uri();

    if ( 'off' !== _x( 'on', 'Google font: on or off', 'nictitate-lite-ii' ) ) {
        $font_url = add_query_arg( 'family', urlencode( 'Titillium Web:400,300,300italic,400italic,600,700|Exo 2:300,400,600,700' ), "//fonts.googleapis.com/css" );
        wp_enqueue_style( 'nictitate-lite-ii-fonts', $font_url, array(), '1.0.0' );
    }

    wp_enqueue_style( 'magnific-popup', $dir . '/assets/css/magnific-popup.css', array(), NULL );
    wp_enqueue_style( 'nictitate-lite-ii-style', get_stylesheet_uri(), array(), NULL );
      
    if ( is_singular() ) {
        wp_enqueue_script( 'comment-reply' );
    }
        
    wp_enqueue_script( 'jquery-form' );
    wp_enqueue_script( 'hoverIntent' );
    wp_enqueue_script( 'masonry' );
    
    wp_enqueue_script( 'bootstrap', $dir . '/assets/js/bootstrap.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'classie', $dir . '/assets/js/classie.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'count-up', $dir . '/assets/js/count-up.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'elevate-zoom', $dir . '/assets/js/elevate-zoom.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'imgliquid', $dir . '/assets/js/imgliquid.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'jflickrfeed', $dir . '/assets/js/jflickrfeed.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'menu-all', $dir . '/assets/js/mmenu-all.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'owl-carousel', $dir . '/assets/js/owl-carousel.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'superfish', $dir . '/assets/js/superfish.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'uisearch', $dir . '/assets/js/uisearch.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'validate', $dir . '/assets/js/validate.js', array( 'jquery' ), null, true );
    wp_enqueue_script( 'jquery-magnific-popup', $dir . '/assets/js/jquery.magnific-popup.js', array( 'jquery' ), null, true );

    wp_enqueue_script( 'nictitate-lite-ii-custom', $dir . '/assets/js/custom.js', array( 'jquery', 'masonry' ), null, true );
    
    wp_localize_script( 'nictitate-lite-ii-custom', 'nictitate_lite_ii', array(
        'template' => array(
            'post_id' => ( is_singular() ) ? get_queried_object_id() : 0,
            'cat_id'  => ( is_category() ) ? get_queried_object_id() : 0,
            'tag_id'  => ( is_category() ) ? get_queried_object_id() : 0,
            'is_home' => is_home() ? 1 : 0,
        ),
        'url' => array(
            'template_directory_uri' => get_template_directory_uri().'/',
            'ajax'                   => admin_url( 'admin-ajax.php' )
        ),
        'form' => array(
            'SUBMIT'  => esc_html__( 'Submit', 'nictitate-lite-ii' ),
            'SENDING' => esc_html__( 'Sending...', 'nictitate-lite-ii' ),
        ),
        'i18n' => array(
            'LOAD_MORE' => esc_html__( 'Load more', 'nictitate-lite-ii' ),
            'LOADING'   => esc_html__( 'Loading..', 'nictitate-lite-ii' ),
            'validate'  => array(
                'form' => array(
                    'CHECKING' => esc_html__( 'Checking', 'nictitate-lite-ii' ),
                    'SEND'     => esc_html__( 'Send', 'nictitate-lite-ii' ),
                    'SENDING'  => esc_html__( 'Sending...', 'nictitate-lite-ii' )
                ),
                'recaptcha' => array(
                    'INVALID'  => esc_html__( 'Your captcha is incorrect. Please try again', 'nictitate-lite-ii' ),
                    'REQUIRED' => esc_html__( 'Captcha is required', 'nictitate-lite-ii' )
                ),
                'name' => array(
                    'REQUIRED'  => esc_html__( 'Please enter your name', 'nictitate-lite-ii' ),
                    'MINLENGTH' => esc_html__( 'At least {0} characters required', 'nictitate-lite-ii' )
                ),
                'subject' => array(
                    'REQUIRED'  => esc_html__( 'Please enter subject', 'nictitate-lite-ii' ),
                    'MINLENGTH' => esc_html__( 'At least {0} characters required', 'nictitate-lite-ii' )
                ),
                'email' => array(
                    'REQUIRED' => esc_html__( 'Please enter your email', 'nictitate-lite-ii' ),
                    'EMAIL'    => esc_html__( 'Please enter a valid email', 'nictitate-lite-ii' )
                ),
                'url' => array(
                    'REQUIRED' => esc_html__( 'Please enter your url', 'nictitate-lite-ii' ),
                    'URL'      => esc_html__( 'Please enter a valid url', 'nictitate-lite-ii' )
                ),
                'message' => array(
                    'REQUIRED'  => esc_html__( 'Please enter a message', 'nictitate-lite-ii' ),
                    'MINLENGTH' => esc_html__( 'At least {0} characters required', 'nictitate-lite-ii' )
                )
            )
        )        
    ));

    // Customize.
    nictitate_lite_ii_customize_breadcrumb();
    nictitate_lite_ii_customize_breaking_news();
    nictitate_lite_ii_customize_css();
}

function nictitate_lite_ii_admin_enqueue_scripts(){
    wp_enqueue_style( 'nictitate-lite-ii-style', get_template_directory_uri() . '/inc/assets/css/admin.style.css', false, '1.0.0' );    
}