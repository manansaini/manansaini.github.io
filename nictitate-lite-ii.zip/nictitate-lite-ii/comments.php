<?php
if ( post_password_required() ) {
    return;
}

if(have_comments()):
?>
<div id="comments" class="comments-area">
    <h2 class="comments-title">
        <?php printf(_n('%1$s thought', '%1$s thoughts', get_comments_number(), 'nictitate-lite-ii'), get_comments_number()); ?> 
        <?php echo esc_html__( 'on', 'nictitate-lite-ii' ); ?>  "<?php the_title(); ?>"
    </h2>
    <ol class="comment-list">
        <?php  
        wp_list_comments(array(
            'walker'     => null,
            'style'      => 'ol',
            'short_ping' => true,
            'callback'   => 'nictitate_comment_list',
            'type'       => 'all'
            )
        );
        ?>
    </ol>

    <?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
        <div class="k-pagination text-right pagination-comment">
            <?php        
            paginate_comments_links(array(
                'prev_text' => '<i class="fa fa-angle-left"></i> prev',
                'next_text' => 'next <i class="fa fa-angle-right"></i>',
                )
            );
            ?>
        </div>
    <?php endif; ?>

    <?php if (!comments_open() && get_comments_number()) : ?>
        <blockquote><?php esc_html_e('Comments are closed.', 'nictitate-lite-ii'); ?></blockquote>
    <?php endif; ?>

</div>
<?php endif; ?>

<?php nictitate_comment_form(); ?>

<?php
function nictitate_comment_list($comment, $args, $depth) {
    $GLOBALS['comment'] = $comment;
    $user_com_id = $comment->user_id;
    ?>
    <li <?php comment_class(); ?> id="comment-<?php comment_ID(); ?>">
        <div class="comment-body">
            <div class="comment-meta">
                <div class="comment-author">
                    <img alt="" src="<?php echo get_avatar_url($user_com_id, array('size' => 56)); ?>" class="avatar">                       
                    <b class="fn"><a href="<?php echo esc_url($comment->comment_author_url); ?>" class="url" target="_blank"><?php echo esc_html($comment->comment_author); ?></a></b>                     
                </div>
                <div class="comment-metadata">
                    <a href="#">
                        <time datetime="<?php echo get_the_date('Y-m-d'); ?>">
                           <?php comment_date(get_option('date_format') ); ?>
                            <?php esc_html_e('at ', 'nictitate-lite-ii');?>
                            <?php comment_date(get_option('time_format') ); ?>                          
                        </time>
                    </a>
                    <?php edit_comment_link(__('Edit', 'nictitate-lite-ii'), '', ''); ?>
                </div>
            </div>
            <div class="comment-content entry-content">
                <?php comment_text(); ?>
            </div>
            <?php comment_reply_link(array_merge($args, array('reply_text' => esc_html__('Reply', 'nictitate-lite-ii'), 'depth' => $depth, 'max_depth' => $args['max_depth']))); ?>                        
        </div>
<?php
}

function nictitate_comment_form( $args = array(), $post_id = null ){ 
    if (null === $post_id){
        $post_id = get_the_ID();
    }

    $commenter         = wp_get_current_commenter();
    $user              = wp_get_current_user();
    $user_identity     = $user->exists() ? $user->display_name : '';
    $args              = wp_parse_args($args);
    $args['format']    = current_theme_supports('html5', 'comment-form') ? 'html5' : 'xhtml';
    $req               = get_option('require_name_email');
    $aria_req          = ( $req ? "aria-required=true" : '' );
    $html5             = 'html5' === $args['format'];
    
    $fields            = array();
    $fields['author']  = nictitate_get_comment_field($aria_req, 'text', 'comment_name', 'author', '', esc_html__('Name( require)', 'nictitate-lite-ii'), '', '');    
    $fields['email']   = nictitate_get_comment_field($aria_req, 'text', 'comment_email', 'email', '', esc_html__('Email( require)', 'nictitate-lite-ii'), '', '');    
    $fields['website'] = nictitate_get_comment_field($aria_req, 'text', 'comment_website', 'website', '', esc_html__('Website', 'nictitate-lite-ii'), '', '');    
    $fields            = apply_filters('comment_form_default_fields', $fields);
    
    $comment_field     = nictitate_get_comment_field_message($aria_req, 'comment_message', 'comment', '', esc_html__('Content', 'nictitate-lite-ii'));
    
    $defaults          = array(
        'fields'               => $fields,
        'comment_field'        => $comment_field,
        'must_log_in'          => '<p class="must-log-in">' . sprintf(__('You must be <a href="%s">logged in</a> to post a comment.', 'nictitate-lite-ii'), wp_login_url(apply_filters('the_permalink', get_permalink($post_id)))) . '</p>',
        'logged_in_as'         => '<p class="logged-in-as">' . sprintf(__('Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>', 'nictitate-lite-ii'), get_edit_user_link(), $user_identity, wp_logout_url(apply_filters('the_permalink', get_permalink($post_id)))) . '</p>',
        'comment_notes_before' => '',
        'comment_notes_after'  => '',
        'id_form'              => 'comments-form',
        'id_submit'            => 'submit-comment',
        'title_reply'          => esc_html__('Leave a Reply', 'nictitate-lite-ii'),
        'title_reply_to'       => esc_html__('Leave a Reply to %s', 'nictitate-lite-ii'),
        'cancel_reply_link'    => esc_html__('(Cancel)', 'nictitate-lite-ii'),
        'label_submit'         => esc_html__('Submit', 'nictitate-lite-ii'),
        'format'               => 'xhtml',
    );

    $args = wp_parse_args($args, apply_filters('comment_form_defaults', $defaults));

    if (comments_open($post_id)) : ?>
        <div id="respond" class="comment-respond">
            <?php do_action('comment_form_after'); ?>
            <h3 id="reply-title" class="comment-reply-title">
                <?php comment_form_title($args['title_reply'], $args['title_reply_to']); ?>
                <?php cancel_comment_reply_link($args['cancel_reply_link']); ?>
            </h3>
            <?php 
            if (get_option('comment_registration') && !is_user_logged_in()) : ?>
                <?php echo wp_kses( $args['must_log_in'], nictitate_lite_ii_get_allowed_tags() ); ?>
                <?php do_action('comment_form_must_log_in_after'); ?>
            <?php 
            else: ?>
            <form action="<?php echo site_url('/wp-comments-post.php'); ?>" method="post" id="<?php echo esc_attr($args['id_form']); ?>" class="comment-form <?php echo esc_attr($html5 ? ' novalidate' : ''); ?>" novalidate="">
                <?php do_action('comment_form_top'); ?>
                
                <?php 
                if( is_user_logged_in() ):
                    echo apply_filters('comment_form_logged_in', $args['logged_in_as'], $commenter, $user_identity);                    
                    do_action('comment_form_logged_in_after', $commenter, $user_identity); ?>
                <?php  

                else:
                    do_action('comment_form_before_fields');
                    foreach ((array) $args['fields'] as $name => $field) {
                        echo apply_filters("comment_form_field_{$name}", $field) . "\n";
                    }
                    do_action('comment_form_after_fields'); 
                endif;
                
                echo apply_filters('comment_form_field_comment', $args['comment_field']);
                echo wp_kses( $args['comment_notes_after'], nictitate_lite_ii_get_allowed_tags() ); 
                
                ?>

                <p class="form-submit">
                    <input 
                        id="<?php echo esc_attr($args['id_submit']); ?>" 
                        name="submit" 
                        type="submit" 
                        class="submit" 
                        value="<?php echo esc_attr($args['label_submit']); ?>">
                        <?php comment_id_fields($post_id); ?>        
                </p> 
                <?php do_action('comment_form', $post_id); ?>                           
            </form>
            <div id="response-1"></div>
            <?php
            endif; 
            do_action('comment_form_after'); ?>
        </div>
    <?php
    else: ?>
        <?php do_action('comment_form_comments_closed'); ?>
    <?php 
    endif; ?>
<?php
}

function nictitate_get_comment_field($aria_req, $type = 'text', $id = '', $name = '', $label = '', $placeholder = '', $before = NULL, $after = NULL) {
    ob_start();
    echo wp_kses( $before, nictitate_lite_ii_get_allowed_tags() ); ?>
    <div class="form-group">
        <input 
            type="<?php echo esc_attr($type); ?>" 
            class="form-control" 
            id="<?php echo esc_attr($id); ?>" 
            name="<?php echo esc_attr($name); ?>"
            placeholder="<?php echo esc_attr($placeholder); ?>">
    </div>
    <?php
    echo wp_kses(  $after, nictitate_lite_ii_get_allowed_tags() );
    return ob_get_clean();
}

function nictitate_get_comment_field_message($aria_req, $id = '', $name = '',  $label = '', $placeholder = '', $before = NULL, $after = NULL, $classes='') {
    ob_start();    

    echo wp_kses( $before, nictitate_lite_ii_get_allowed_tags() );
    ?>
    <div class="form-group">                                
        <textarea <?php echo esc_attr($aria_req); ?> 
            id="<?php echo esc_attr($id); ?>" 
            name="<?php echo esc_attr($name); ?>" 
            class="form-control" 
            placeholder="<?php echo esc_attr($placeholder); ?>"></textarea>
    </div>
    <?php
    echo wp_kses( $after, nictitate_lite_ii_get_allowed_tags() );
    return ob_get_clean();
}