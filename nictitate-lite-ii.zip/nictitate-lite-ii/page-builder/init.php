<?php

if ( class_exists( 'Kopa_Page_Builder' ) && ! class_exists( 'Nictitate_Lite_II_Builder' ) ) {

	class Nictitate_Lite_II_Builder_Layout {

		public static function get_layout_ultimate() {

			$layout = array(
				'title'     => esc_html__( 'Ultimate', 'nictitate-lite-ii' ),
				'preview'   => get_template_directory_uri() . '/page-builder/images/ultimate.png',
				'customize' => array(),
				'section'   => array()
			);	

			$layout['customize']['custom']['title']         = esc_html__('Custom', 'nictitate-lite-ii');
			$layout['customize']['custom']['params']['css'] = array(
				'type'    => 'textarea',
				'title'   => esc_html__('CSS code', 'nictitate-lite-ii'),
				'default' => '',
				'rows'    => 10   
			);

			$header_styles = nictitate_lite_ii_get_header_style( true );
			$header_styles = array_merge( array( ''=> esc_html__( '-- Select a style --', 'nictitate-lite-ii' ) ), $header_styles );

			if( !empty( $header_styles ) ){
				$layout['customize']['header']['title'] = esc_html__('Header', 'nictitate-lite-ii');
				$layout['customize']['header']['params']['style'] = array(
					'type'    => 'select',
					'title'   => esc_html__('Style', 'nictitate-lite-ii'),
					'options' => $header_styles,
					'default' => 'style-1'
				);
			}

			$layout['section']['row-1'] = array(
				'title'        => esc_html__('Row 1', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(12),
				'grid_classes' => array('col-xs-12'),
				'customize'    => array(),        		
				'area'         => array('area-1'),					
			);

			$layout['section']['row-2'] = array(
				'title'        => esc_html__('Row 2', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(8,4),
				'grid_classes' => array( 'col-xs-12', 'col-xs-12' ),
				'customize'    => array(),        		
				'area'         => array('area-2-1', 'area-2-2'),
			);

			$layout['section']['row-3'] = array(
				'title'        => esc_html__('Row 3', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(12),
				'grid_classes' => array('col-xs-12'),
				'customize'    => array(),        		
				'area'         => array('area-3'),
			);

			$layout['section']['row-4'] = array(
				'title'        => esc_html__('Row 4', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(4,8),
				'grid_classes' => array( 'col-xs-12', 'col-xs-12' ),
				'customize'    => array(),        		
				'area'         => array('area-4-1', 'area-4-2'),
			);

			$layout['section']['row-5'] = array(
				'title'        => esc_html__('Row 5', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(12),
				'grid_classes' => array('col-xs-12'),
				'customize'    => array(),        		
				'area'         => array('area-5'),
			);

			$layout['section']['row-6'] = array(
				'title'        => esc_html__('Row 6', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(6,6),
				'grid_classes' => array( 'col-xs-12', 'col-xs-12' ),
				'customize'    => array(),        		
				'area'         => array('area-6-1', 'area-6-2'),
			);

			$layout['section']['row-7'] = array(
				'title'        => esc_html__('Row 7', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(12),
				'grid_classes' => array('col-xs-12'),
				'customize'    => array(),        		
				'area'         => array('area-7'),
			);

			$layout['section']['row-8'] = array(
				'title'       => esc_html__('Row 8', 'nictitate-lite-ii'),
				'description' => '',
				'grid'        => array(4,4,4),
				'grid_classes' => array( 'col-xs-12', 'col-xs-12', 'col-xs-12' ),
				'customize'   => array(),        		
				'area'        => array('area-8-1', 'area-8-2', 'area-8-3'),
			);

			$layout['section']['row-9'] = array(
				'title'        => esc_html__('Row 9', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(12),
				'grid_classes' => array('col-xs-12'),
				'customize'    => array(),        		
				'area'         => array('area-9'),
			);

			$layout['section']['row-10'] = array(
				'title'       => esc_html__('Row 10', 'nictitate-lite-ii'),
				'description' => '',
				'grid'        => array(3,3,3,3),
				'grid_classes' => array( 'col-sm-6 col-xs-12', 'col-sm-6 col-xs-12', 'col-sm-6 col-xs-12', 'col-sm-6 col-xs-12' ),
				'customize'   => array(),        		
				'area'        => array('area-10-1', 'area-10-2', 'area-10-3', 'area-10-4'),					
			);

			$layout['section']['row-11'] = array(
				'title'        => esc_html__('Row 11', 'nictitate-lite-ii'),
				'description'  => '',
				'grid'         => array(12),
				'grid_classes' => array('col-xs-12'),
				'customize'    => array(),        		
				'area'         => array('area-11'),
			);
		
			return $layout;
		}
	}

	class Nictitate_Lite_II_Builder{

		public function __construct(){
			add_action( 'init', array($this, 'init') );	
			add_filter( 'body_class', array($this, 'body_class') );
			add_filter( 'kopa_page_builder_get_areas', array('Nictitate_Lite_II_Builder', 'set_areas') );
			add_filter( 'kopa_page_builder_get_layouts', array('Nictitate_Lite_II_Builder', 'set_layouts') );
			add_filter( 'kopa_page_builder_get_section_fields', array('Nictitate_Lite_II_Builder', 'set_section_fields') );			
			add_filter( 'kopa_page_builder_get_customize_fields', array('Nictitate_Lite_II_Builder', 'set_widget_fields') );
			
			add_action( 'kopa_page_builder_after_save_widget', array('Nictitate_Lite_II_Builder', 'clear_cache'), 10, 1 );
			add_action( 'kopa_page_buider_after_save_grid', array('Nictitate_Lite_II_Builder', 'clear_cache'), 10, 1 );
			add_action( 'kopa_page_builder_after_save_section_customize', array('Nictitate_Lite_II_Builder', 'clear_cache'), 10, 1 );
			add_action( 'kopa_page_builder_after_save_layout_customize', array('Nictitate_Lite_II_Builder', 'clear_cache'), 10, 1 );

			add_action( 'wp_enqueue_scripts', array($this, 'enqueue_script'), 20);
			add_filter( 'theme_mod_header-style', array($this, 'get_header_style') );

			add_action( 'template_redirect', array( $this, 'template_redirect' ) );
		}

		public function init(){
			add_filter('nictitate_lite_ii_get_page_template', array($this, 'get_page_template'));				
		}

		public function get_page_template($template){
			if(is_page()){
				global $post;
				$layout = Kopa_Page_Builder::get_current_layout($post->ID);

				if( ! in_array( $layout, array( '', 'disable' ) ) ){
			 		$template = sprintf( 'page-builder/layouts/%s', $layout );
			 	}	
			}

			return $template;
		}

		public function body_class($classes){
			array_push($classes, 'nictitate-builder');
			return $classes;
		}

		public function get_spacing( $element, $type='margin', $data=array( 'top'=>'', 'bottom' => '', 'left' => '', 'right' => '' ) ){
			$css = '';
			unset( $data['alert'] );

			foreach( $data as $key => $value ){					
				if( '' !== $value){
					$css .= sprintf( '%s-%s: %spx;', $type, $key, $value );
				}
			}
			if( !empty( $css ) ){
				$css = sprintf('%s { %s }', $element, $css );
			}
			return $css;
		}

		public function get_header_style($style){
			if( is_page() ){
				global $post;

				$cache = get_transient( self::get_cache_key( $post->ID ) );
				if( ! empty( $cache ) ){
					if( isset( $cache['layout']['customize']['header']['style'] ) ){
						$selected = esc_attr( $cache['layout']['customize']['header']['style'] );
						if( !empty( $selected ) ){
							$style = $selected;
						}						
					}
				}
			}
			return $style;
		}

		public function template_redirect(){
			if( is_page() ){
				global $post;

				$is_use_map_api = false;
				$css            = '';						
				$cache          = get_transient( self::get_cache_key( $post->ID ) );

				if( empty( $cache ) ){

					$layout_slug = Kopa_Page_Builder::get_current_layout( $post->ID );

			        if( ! empty($layout_slug) && ( 'disable' !== $layout_slug ) ){

			        	$data  = Kopa_Page_Builder::get_current_layout_data( $post->ID );													
						$layout_customize = wp_parse_args( Kopa_Page_Builder::get_layout_customize_data( $post->ID, $layout_slug ), Nictitate_Lite_II_Builder::get_layout_default_args() );	

						$layouts  = apply_filters( 'kopa_page_builder_get_layouts', array() );
						$layout   = $layouts[$layout_slug];							
						$sections = $layout['section'];			

						if( !empty( $layout_customize['custom']['css'] ) ){
							$css .= $layout_customize['custom']['css'];
						}
						
						if( count($sections) > 0 ){
						
							foreach($sections as $section_slug => $section){
								
								$container_data = $data[$section_slug];

								if( !empty( $container_data ) ){
									$container = Kopa_Page_Builder::get_current_wrapper_data( $post->ID, $layout_slug, $section_slug );								
									$container = wp_parse_args( $container, Nictitate_Lite_II_Builder::get_section_default_args() );

									// begin: container.
									if('true' === $container['container']['is_use'] ){
										$container_css  = '';																		

										if( !empty( $container ) ){										
											$container_css .= $this->get_spacing( 'ID', 'margin', $container['margin'] );
											$container_css .= $this->get_spacing( 'ID', 'padding', $container['padding'] );
											$container_css .= $container['custom']['css'];
										}

										if( ! empty( $container['bg']['bg_image'] ) ){
											$container_css .= sprintf( 'ID { background-image: url("%s"); }', esc_url( do_shortcode( $container['bg']['bg_image'] ) ) );
										}

										if( ! empty( $container['bg']['bg_color'] ) ){
											$container_css .= sprintf( 'ID { background-color: %s; }', esc_attr( $container['bg']['bg_color'] ) );
										}

										if( ! empty( $container['bg']['bg_repeat'] ) ){
											$container_css .= sprintf( 'ID { background-repeat: %s; }', esc_attr( $container['bg']['bg_repeat'] ) );
										}

										if( ! empty( $container['bg']['bg_position'] ) ){
											$container_css .= sprintf( 'ID { background-repeat: %s; }', esc_attr( $container['bg']['bg_position'] ) );
										}

										if( ! empty( $container['bg']['bg_attachment'] ) ){
											$container_css .= sprintf( 'ID { background-repeat: %s; }', esc_attr( $container['bg']['bg_attachment'] ) );
										}


										if( ! empty( $container_css ) ){
											$container_css = str_replace('ID', sprintf( '#nictitate-%s', $section_slug ), $container_css );
											$css           .= $container_css;
										}					
									}		
									// end: container.

									
									$areas = $section['area'];									
									foreach( $areas as $area ){
										if( isset( $container_data[$area] ) && !empty( $container_data[$area] ) ){
											$widgets = $container_data[$area];

											foreach( $widgets as $widget_id => $widget ){

												if( ! $is_use_map_api ){
													$map_class_names = apply_filters('nictitate_get_map_class_name', array());

													if( in_array( $widget['class_name'], $map_class_names ) ){
														$is_use_map_api = true;	
													}
												}

												$widget_css  = '';

												$widget_data = get_post_meta( $post->ID, $widget_id, true );
												$widget_data = wp_parse_args( $widget_data['customize'], Nictitate_Lite_II_Builder::get_widget_default_args() );

												$widget_css .= $this->get_spacing( 'ID', 'margin', $widget_data['margin'] );
												$widget_css .= $this->get_spacing( 'ID', 'padding', $widget_data['padding'] );
												$widget_css .= $widget_data['custom']['css'];

												if( ! empty( $widget_data['container']['bg_image'] ) ){
													$widget_css .= sprintf( 'ID { background-image: url("%s"); }', esc_url( $widget_data['container']['bg_image'] ) );
												}

												if( ! empty( $widget_data['container']['bg_color'] ) ){
													$widget_css .= sprintf( 'ID { background-color: %s; }', esc_attr( $widget_data['container']['bg_color'] ) );
												}

												if( ! empty( $widget_data['overlay']['bg_image'] ) ){
													$widget_css .= sprintf( 'ID > .overlay{ background-image: url("%s"); }', esc_url( $widget_data['overlay']['bg_image'] ) );
												}

												if( ! empty( $widget_data['overlay']['bg_color'] ) ){
													$bg_color = $widget_data['overlay']['bg_color'];
													if( ! empty( $widget_data['overlay']['opacity'] ) ){
														$bg_color = nictitate_lite_ii_get_rgba($bg_color, $widget_data['overlay']['opacity'] );
													}

													$widget_css .= sprintf( 'ID > .overlay{ background-color: %s; background-repeat: repeat; background-position: center center; }', esc_attr( $bg_color ) );
												}

												if( ! empty( $widget_css ) ){
													$widget_css = str_replace('ID', sprintf( '#%s', $widget_id ), $widget_css );
													$css        .= $widget_css;
												}
											}
										}
									}
								}
							}

						}

				        $cache = array();
						$cache['css']                      = $css;
						$cache['config']['is_use_map_api'] = $is_use_map_api;
						$cache['layout']['customize']      = $layout_customize;						

				        set_transient( self::get_cache_key( $post->ID ) , $cache, 365 * 7 * 24 * 60 * 60 );

			        }		          	
			    
				}
			
			}
		}

		public function enqueue_script(){
			if( is_page() ){
				global $post;
				
				$is_use_map_api = false;
				$css            = '';						
				$cache          = get_transient( self::get_cache_key( $post->ID ) );					

				if( ! empty( $cache ) ){

					if( isset( $cache['css'] ) ){
						$css = $cache['css'];
					}

					if( isset( $cache['config']['is_use_map_api'] ) ){
						$is_use_map_api = $cache['config']['is_use_map_api'];
					}
				
					wp_add_inline_style( 'nictitate-lite-ii-style', $css );

					if( $is_use_map_api ){
						wp_enqueue_script('nictitate-maps-api', 'http://maps.google.com/maps/api/js?sensor=true', array('jquery'), NULL, TRUE);
                		wp_enqueue_script('nictitate-maps', get_template_directory_uri() . '/assets/js/gmap.js', array('jquery'), NULL, TRUE);
                		wp_enqueue_script('nictitate-maps-init', get_template_directory_uri() . '/assets/js/gmap.init.js', array('jquery'), NULL, TRUE);
					}

				}
		    }
		}	

		public static function set_areas($areas){

			$areas['area-1']    = esc_html__('Area 1', 'nictitate-lite-ii');
			$areas['area-2-1']  = esc_html__('Area 2.1', 'nictitate-lite-ii');
			$areas['area-2-2']  = esc_html__('Area 2.2', 'nictitate-lite-ii');
			$areas['area-3']    = esc_html__('Area 3', 'nictitate-lite-ii');
			$areas['area-4-1']  = esc_html__('Area 4.1', 'nictitate-lite-ii');
			$areas['area-4-2']  = esc_html__('Area 4.2', 'nictitate-lite-ii');
			$areas['area-5']    = esc_html__('Area 5', 'nictitate-lite-ii');
			$areas['area-6-1']  = esc_html__('Area 6.1', 'nictitate-lite-ii');
			$areas['area-6-2']  = esc_html__('Area 6.2', 'nictitate-lite-ii');
			$areas['area-7']    = esc_html__('Area 7', 'nictitate-lite-ii');
			$areas['area-8-1']  = esc_html__('Area 8.1', 'nictitate-lite-ii');
			$areas['area-8-2']  = esc_html__('Area 8.2', 'nictitate-lite-ii');
			$areas['area-8-3']  = esc_html__('Area 8.3', 'nictitate-lite-ii');
			$areas['area-9']    = esc_html__('Area 9', 'nictitate-lite-ii');
			$areas['area-10-1'] = esc_html__('Area 10.1', 'nictitate-lite-ii');
			$areas['area-10-2'] = esc_html__('Area 10.2', 'nictitate-lite-ii');
			$areas['area-10-3'] = esc_html__('Area 10.3', 'nictitate-lite-ii');
			$areas['area-10-4'] = esc_html__('Area 10.4', 'nictitate-lite-ii');
			$areas['area-11']   = esc_html__('Area 11', 'nictitate-lite-ii');

			return $areas;
		}
		
		public static function set_layouts($layouts){
		    $layouts['disable'] = array(
		       'title' => esc_html__('-- Disable --', 'nictitate-lite-ii')        
		    );			    
			$layouts['ultimate']  = Nictitate_Lite_II_Builder_Layout::get_layout_ultimate();

		    return $layouts;
		}

		public static function set_section_fields($fields){
			// CONTAINER.
			$fields['container']['title']  = esc_html__('Container', 'nictitate-lite-ii');	
			$fields['container']['params'] = array();				
			
			$fields['container']['params']['is_use'] = array(
				'type'    => 'radio',
				'title'   => esc_html__('Is use section tag ?', 'nictitate-lite-ii'),
				'default' => 'false',								
				'options' => array(
					'true'  => esc_html__('Yes', 'nictitate-lite-ii'),
					'false' => esc_html__('No', 'nictitate-lite-ii'),
				)
			);

			$fields['container']['params']['is_boxed'] = array(
				'type'    => 'radio',
				'title'   => esc_html__('Is boxed ?', 'nictitate-lite-ii'),
				'default' => 'false',								
				'help'    => esc_html__('This option only working if has only one widget inside.', 'nictitate-lite-ii'),
				'options' => array(
					'true'  => esc_html__('Yes', 'nictitate-lite-ii'),
					'false' => esc_html__('No', 'nictitate-lite-ii'),
				)
			);


			// BACKGROUND.
			$fields['bg']['title'] = esc_html__('Background', 'nictitate-lite-ii');				
			
			$fields['bg']['params']['alert'] = array(
				'type'          => 'alert',
				'is_hide_title' => true,
				'message'       => esc_html__('Only works when the option "Is use section tag" switch YES !!!', 'nictitate-lite-ii')
			);	

			$fields['bg']['params']['bg_image'] = array(
				'type'    => 'image',
				'title'   => esc_html__( 'Background image', 'nictitate-lite-ii' ),
				'default' => ''
			);				

			$fields['bg']['params']['bg_color'] = array(
				'type'    => 'color',
				'title'   => esc_html__( 'Background color', 'nictitate-lite-ii' ),
				'default' => ''
			);

			$fields['bg']['params']['bg_repeat'] = array(
				'type'    => 'select',
				'title'   => esc_html__( 'Background repeat', 'nictitate-lite-ii' ),					
				'default' => 'repeat',
				'options' => array(
					'repeat'    => esc_html__( 'repeat', 'nictitate-lite-ii' ),
					'repeat-x'  => esc_html__( 'repeat-x', 'nictitate-lite-ii' ),
					'repeat-y'  => esc_html__( 'repeat-y', 'nictitate-lite-ii' ),
					'no-repeat' => esc_html__( 'no-repeat', 'nictitate-lite-ii' ),
					'initial'   => esc_html__( 'initial', 'nictitate-lite-ii' ),
					'inherit'   => esc_html__( 'inherit', 'nictitate-lite-ii' ),
				)
			);

			$fields['bg']['params']['bg_position'] = array(
				'type'    => 'select',
				'title'   => esc_html__( 'Background position', 'nictitate-lite-ii' ),					
				'default' => 'center center',
				'options' => array(						
					'left top'      => esc_html__( 'left top', 'nictitate-lite-ii' ),		
					'left center'   => esc_html__( 'left center', 'nictitate-lite-ii' ),		
					'left bottom'   => esc_html__( 'left bottom', 'nictitate-lite-ii' ),		
					'right top'     => esc_html__( 'right top', 'nictitate-lite-ii' ),		
					'right center'  => esc_html__( 'right center', 'nictitate-lite-ii' ),		
					'right bottom'  => esc_html__( 'right bottom', 'nictitate-lite-ii' ),		
					'center top'    => esc_html__( 'center top', 'nictitate-lite-ii' ),		
					'center center' => esc_html__( 'center center', 'nictitate-lite-ii' ),		
					'center bottom' => esc_html__( 'center bottom', 'nictitate-lite-ii' ),		
				)
			);

			$fields['bg']['params']['bg_attachment'] = array(
				'type'    => 'select',
				'title'   => esc_html__( 'Background attachment', 'nictitate-lite-ii' ),					
				'default' => 'scroll',
				'options' => array(						
					'scroll'  => esc_html__( 'Scroll', 'nictitate-lite-ii' ),
					'fixed'   => esc_html__( 'Fixed', 'nictitate-lite-ii' ),
					'local'   => esc_html__( 'Local', 'nictitate-lite-ii' ),						
					'initial' => esc_html__( 'initial', 'nictitate-lite-ii' ),
					'inherit' => esc_html__( 'inherit', 'nictitate-lite-ii' ),	
				)
			);				

			// MARGIN.
			$fields['margin']['title']  = esc_html__('Margin', 'nictitate-lite-ii');
			$fields['margin']['params'] = array();	
			
			$fields['margin']['params']['alert'] = array(
				'type'          => 'alert',
				'is_hide_title' => true,
				'message'       => esc_html__('Only works when the option "Is use section tag" switch YES !!!', 'nictitate-lite-ii')
			);

			$fields['margin']['params']['top'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Top', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['margin']['params']['bottom'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Bottom', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['margin']['params']['left'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Left', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['margin']['params']['right'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Right', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);

			// PADDING.
			$fields['padding']['title']  = esc_html__('Padding', 'nictitate-lite-ii');	
			$fields['padding']['params'] = array();	

			$fields['padding']['params']['alert'] = array(
				'type'          => 'alert',
				'is_hide_title' => true,
				'message'       => esc_html__('Only works when the option "Is use section tag" switch YES !!!', 'nictitate-lite-ii')
			);

			$fields['padding']['params']['top'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Top', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['padding']['params']['bottom'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Bottom', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['padding']['params']['left'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Left', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['padding']['params']['right'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Right', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);

			// CUSTOM.
			$fields['custom']['title']         =  esc_html__('Custom', 'nictitate-lite-ii');	
			$fields['custom']['params']        = array();			
			
			$fields['custom']['params']['alert'] = array(
				'type'          => 'alert',
				'is_hide_title' => true,
				'message'       => esc_html__('Only works when the option "Is use section tag" switch YES !!!', 'nictitate-lite-ii')
			);

			$fields['custom']['params']['css'] = array(
				'type'    => 'textarea',
				'title'   => esc_html__('CSS code', 'nictitate-lite-ii'),
				'default' => '',
				'rows'    => 5,       
				'class'   => 'kpb-ui-textarea-guide-line',
				'help'    => wp_kses_post( __('Example: <code>ID a {color: red; }</code> <br/> ID: The ID of section.', 'nictitate-lite-ii') ),
			);							

			return $fields;
		}

		public static function set_widget_fields($fields){
			// TITLE.
			$fields['title']['title']  =  esc_html__('Title', 'nictitate-lite-ii');	
			$fields['title']['params'] = array();
			$fields['title']['params']['style'] = array(
				'type'    => 'select',
				'title'   => esc_html__('Style', 'nictitate-lite-ii'),
				'default' => 'default',								
				'options' => array(
					'default'      => esc_html__('-- Default --', 'nictitate-lite-ii'),						
					'h3-with-more' => esc_html__('Title with more link', 'nictitate-lite-ii'),
					'h3-with-sub-icon'  => esc_html__('Title with sub-text & icon', 'nictitate-lite-ii'),
					'h3-with-aff'  => esc_html__('Title with affix', 'nictitate-lite-ii'),
					'h3-with-pre'  => esc_html__('Title with prefix', 'nictitate-lite-ii'),
				)
			);
			
			$fields['title']['params']['highlight'] = array(
				'type'    => 'text',
				'title'   => esc_html__('Highlight words', 'nictitate-lite-ii'),
				'default' => ''	
			);

			$fields['title']['params']['subtitle'] = array(
				'type'    => 'textarea',
				'title'   => esc_html__('Sub title', 'nictitate-lite-ii'),
				'default' => ''	
			);
			
			$fields['title']['params']['icon'] = array(
				'type'  => 'text',
				'title' => esc_html__('Icon', 'nictitate-lite-ii'),
				'help'  => wp_kses_post( sprintf(__('Please enter class of <a href="%s" target="_blank">Font Awesome</a>. Example: fa fa-car,..', 'nictitate-lite-ii'), 'https://fortawesome.github.io/Font-Awesome/icons/') )
			);
			
			$fields['title']['params']['more_text'] = array(
				'type'    => 'text',
				'title'   => esc_html__('More text', 'nictitate-lite-ii'),
				'default' => esc_html__('Learn more', 'nictitate-lite-ii'),
			);

			$fields['title']['params']['more_url'] = array(
				'type'    => 'text',
				'title'   => esc_html__('More link', 'nictitate-lite-ii'),
				'default' => 'http://'
			);

			// CONTAINER.
			$fields['container']['title']  =  esc_html__('Container', 'nictitate-lite-ii');	
			$fields['container']['params'] = array();				
			
			$fields['container']['params']['is_boxed'] = array(
				'type'    => 'radio',
				'title'   => esc_html__('Is boxed', 'nictitate-lite-ii'),
				'default' => 'false',								
				'options' => array(
					'true'  => esc_html__('Yes', 'nictitate-lite-ii'),
					'false' => esc_html__('No', 'nictitate-lite-ii'),
				)
			);

			$fields['container']['params']['is_parallax'] = array(
				'type'    => 'radio',
				'title'   => esc_html__( 'Is parallax', 'nictitate-lite-ii' ),
				'default' => 'false',								
				'options' => array(
					'true'  => esc_html__( 'Yes', 'nictitate-lite-ii' ),
					'false' => esc_html__( 'No', 'nictitate-lite-ii' ),
				)
			);	

			$fields['container']['params']['bg_image'] = array(
				'type'    => 'image',
				'title'   => esc_html__( 'Background image', 'nictitate-lite-ii' ),
				'default' => ''
			);

			$fields['container']['params']['bg_color'] = array(
				'type'    => 'color',
				'title'   => esc_html__( 'Background color', 'nictitate-lite-ii' ),
				'default' => ''
			);

			// PARALLAX.
			$fields['overlay']['title']  =  esc_html__('Overlay', 'nictitate-lite-ii');	
			$fields['overlay']['params'] = array();	
			
			
			$fields['overlay']['params']['bg_image'] = array(
				'type'    => 'image',
				'title'   => esc_html__( 'Background image', 'nictitate-lite-ii' ),
				'default' => ''
			);
			
			$fields['overlay']['params']['bg_color'] = array(
				'type'    => 'color',
				'title'   => esc_html__( 'Background color', 'nictitate-lite-ii' ),
				'default' => ''
			);

			$fields['overlay']['params']['opacity'] = array(
				'type'    => 'text',
				'title'   => esc_html__( 'Opacity', 'nictitate-lite-ii' ),
				'default' => 0.7
			);

			// MARGIN.
			$fields['margin']['title']  = esc_html__('Margin', 'nictitate-lite-ii');	
			$fields['margin']['params'] = array();	
			$fields['margin']['params']['top'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Top', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['margin']['params']['bottom'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Bottom', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['margin']['params']['left'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Left', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['margin']['params']['right'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Right', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);

			// PADDING.
			$fields['padding']['title']  = esc_html__('Padding', 'nictitate-lite-ii');	
			$fields['padding']['params'] = array();	
			$fields['padding']['params']['top'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Top', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['padding']['params']['bottom'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Bottom', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['padding']['params']['left'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Left', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);
			$fields['padding']['params']['right'] = array(
				'type'    => 'number',
				'title'   => esc_html__('Right', 'nictitate-lite-ii'),
				'default' => '',
				'affix'   => 'px'
			);				

					
			// CUSTOM.
			$fields['custom']['title']         =  esc_html__('Custom', 'nictitate-lite-ii');	
			$fields['custom']['params']        = array();				
			$fields['custom']['params']['css'] = array(
				'type'    => 'textarea',
				'title'   => esc_html__('CSS code', 'nictitate-lite-ii'),
				'default' => '',
				'rows'    => 5,       
				'class'   => 'kpb-ui-textarea-guide-line',
				'help'    => wp_kses_post( __('Example: <code>ID a {color: red; }</code> <br/> ID: The ID of widget.', 'nictitate-lite-ii') ),
			);

			return $fields;
		}

		public static function get_layout_default_args(){
			$data = array();


			$data['custom'] = array(
				'css' => ''
			);

			$headers = nictitate_lite_ii_get_header_style();
			if( !empty( $headers ) ){
				$data['header'] = array(
					'style' => 'style-1'
				);					
			}

			return $data;
		}

		public static function get_section_default_args(){
			$data = array(
				'container' => array(
					'is_use'   => 'false',
					'is_boxed' => 'false',
					'bg_color' => '',
					'bg_image' => '',
				),
				'bg' => array(
					'bg_image'      => '',
					'bg_color'      => '',
					'bg_repeat'     => 'repeat',
					'bg_position'   => 'center center',
					'bg_attachment' => 'scroll',
				),
				'margin' => array(
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',
				),
				'padding' => array(
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',	
				),
				'custom' => array(
					'css' => ''
				)
			);

			return $data;
		}

		public static function get_widget_default_args(){
			$data = array(
				'title' => array(
					'style'     => 'default',
					'highlight' => '',
					'subtitle'  => '',
					'icon'      => '',
					'more_text' => '',
					'more_link' => '',
				),
				'container' => array(
					'is_boxed'    => 'false',
					'is_parallax' => 'false',
					'bg_image'    => '',
				),
				'overlay' => array(						
					'bg_image' => '',
					'bg_color' => '',
					'opacity'  => 0.7,
				),
				'margin' => array(
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',
				),
				'padding' => array(
					'top'    => '',
					'bottom' => '',
					'left'   => '',
					'right'  => '',	
				),
				'custom' => array(
					'css' => '',
				),

			);

			return $data;
		}

		public static function print_before_section( $layout, $section_slug, $is_only_one=true ){
			global $post;
			$section = Kopa_Page_Builder::get_current_wrapper_data($post->ID, $layout, $section_slug);			
			$section = wp_parse_args($section, Nictitate_Lite_II_Builder::get_section_default_args());	
			
			if('true' === $section['container']['is_use'] ){
				echo sprintf( '<section id="nictitate-%s" class="n_section">', $section_slug );
			}

			if( $is_only_one ) {
				if( 'true' === $section['container']['is_boxed'] ){
					echo '<div class="container">';
				}
			}
		}

		public static function print_after_section( $layout, $section_slug, $is_only_one=true){	
			global $post;
			$section = Kopa_Page_Builder::get_current_wrapper_data($post->ID, $layout, $section_slug);			
			$section = wp_parse_args($section, Nictitate_Lite_II_Builder::get_section_default_args());
			
			if( $is_only_one ) {
				if( 'true' === $section['container']['is_boxed'] ){
					echo '</div>';
				}
			}

			if('true' === $section['container']['is_use'] ){
				echo '</section>';
			}
		}

		public static function print_area( $post_id, $data ){
			
			if($data){
				
				foreach($data as $widget_id => $widget){

					if($widget_data = get_post_meta($post_id, $widget_id, true)){
						
						$class_name = $widget['class_name'];	                                    

						if(class_exists($class_name)){

							$instance    = $widget_data['widget'];
							$obj         = new $class_name;
							$obj->id     = $widget_id;
							$obj->number = rand(0, 9999);

				            $widget_wrap = array(
								'before_widget' => '<div id="%1$s" class="widget k-widget %2$s">',
								'after_widget'  => '</div>',
								'before_title'  => '<h3 class="widget-title">',
								'after_title'   => '</h3>'
				            );

							$customize_data = wp_parse_args( $widget_data['customize'], Nictitate_Lite_II_Builder::get_widget_default_args() );								

							$highlight  = esc_attr( $customize_data['title']['highlight'] );

		            		switch ( $customize_data['title']['style'] ) {
		            			case 'h3-with-more':
									$more_text = esc_attr( $customize_data['title']['more_text'] );
									$more_url  = esc_url( $customize_data['title']['more_url'] );
										
									if( $highlight ){
										$widget_wrap['after_title'] = ' ' . sprintf( '<span>%s</span>', $highlight) . $widget_wrap['after_title'];
									}

									if( $more_text && $more_url ){
    			        				$widget_wrap['after_title'] .= sprintf( '<a href="%s" class="read-more-list">%s</a>', $more_url, $more_text);
		        					}
		            				break;

		            			case 'h3-with-sub-icon':
									$icon     = esc_attr( $customize_data['title']['icon'] );
									$subtitle = esc_attr( $customize_data['title']['subtitle'] );

									$obj->widget_options['classname'] .= ' has-header has-icon-header';											
									$widget_wrap['before_title']      = '<div class="widget-header ">';
									if( $icon ){
										$widget_wrap['before_title']  .= sprintf( '<i class="icon"><span class="i %s"></span></i>', $icon );
									}
									$widget_wrap['before_title'] .= '<h3 class="widget-title">';											
									
									$widget_wrap['after_title']  = '</h3>';	
									if( $highlight ){
										$widget_wrap['after_title'] = ' ' . sprintf( '<span>%s</span>', $highlight) . $widget_wrap['after_title'];
									}

									if( $subtitle ){
										$widget_wrap['after_title']  .= sprintf( '<p class="widget-des">%s</p>', $subtitle );
									}
									$widget_wrap['after_title']  .= '</div>';
		            				break;

		            			case 'h3-with-pre':
		            				$subtitle = esc_attr( $customize_data['title']['subtitle'] );

									$obj->widget_options['classname'] .= ' has-header';											
									if( $subtitle ){
										$widget_wrap['before_title'] = sprintf( '<h4 class="widget-des">%s</h4>%s', $subtitle, $widget_wrap['before_title'] );
									}

									if( $highlight ){
										$widget_wrap['after_title'] = ' ' . sprintf( '<span>%s</span>', $highlight) . $widget_wrap['after_title'];
									}
																			
		            				break;

		            			
		            			case 'h3-with-aff':
		            				$subtitle = esc_attr( $customize_data['title']['subtitle'] );

									$obj->widget_options['classname'] .= ' k-widget-progress';											
									$widget_wrap['after_title'] = '</h3>';
									if( $highlight ){
										$widget_wrap['after_title'] = ' ' . sprintf( '<span>%s</span>', $highlight) . $widget_wrap['after_title'];
									}

									if( $subtitle ){
										$widget_wrap['after_title'] .= sprintf( '<h4 class="widget-des">%s</h4>', $subtitle);
									}
																			
		            				break;
		            		}				            		

		            		if( 'true' === $customize_data['container']['is_parallax'] ){
		            			$obj->widget_options['classname'] .= ' k-parallax';			            			
		            		}

			            	$widget_wrap['before_widget'] = sprintf( $widget_wrap['before_widget'], $obj->id, $obj->widget_options['classname'] );
			
		            		if( !empty( $customize_data['overlay']['bg_image'] ) || !empty( $customize_data['overlay']['bg_color'] ) ){
		            			$widget_wrap['before_widget'] .= '<div class="overlay">';
		            			$widget_wrap['after_widget'] = '</div>' . $widget_wrap['after_widget'];
		            		}
		            		if( 'true' === $customize_data['container']['is_boxed'] ){ 
			            		$widget_wrap['before_widget'] .= '<div class="container">';
			            		$widget_wrap['after_widget'] = '</div>' . $widget_wrap['after_widget'];
			            	}
			            	$obj->widget( $widget_wrap, $instance );

						}

					}

				}					

			}
		}

		public static function print_page( $post_id, $info ){

			$layout = Kopa_Page_Builder::get_current_layout( $post_id ); 
			$data   = Kopa_Page_Builder::get_current_layout_data( $post_id );

			foreach ($data as $row_slug => $row) {

				if( ! empty( $data[$row_slug] ) ){

					$grid = $info['section'][$row_slug]['grid'];
			
					$is_only_one = self::is_only_one( $data[$row_slug] );

					Nictitate_Lite_II_Builder::print_before_section( $layout, $row_slug, $is_only_one);

					if( ! $is_only_one ){
						echo '<div class="row">';
					}

					$loop_index = 0;
					foreach ( $row as $col_slug => $col ) {

						if( ! $is_only_one ){
							$col_classes = $info['section'][$row_slug]['grid_classes'];
							printf( '<div class="col-lg-%s %s">', $grid[ $loop_index ], $col_classes[$loop_index] );
						}

						if( isset( $data[ $row_slug ][ $col_slug ] ) ){
							Nictitate_Lite_II_Builder::print_area( $post_id, $data[$row_slug][$col_slug] ); 
						}

						if( ! $is_only_one ){
							echo '</div>';
						}

						$loop_index++;
					}

					if( ! $is_only_one ){
						echo '</div>';
					}			

					Nictitate_Lite_II_Builder::print_after_section( $layout, $row_slug, $is_only_one);						

				}
			}
		}

		public static function is_only_one( $data ){
			$is_only_one = false;

			if( !empty( $data ) ){
				$count = 0;
				foreach ( $data as $area_slug => $area ) {
					$count += count( $area );
				}

				if( 1 === $count ){
					$is_only_one = true;
				}
			}

			return $is_only_one;
		}

		public static function clear_cache( $post_id ){								
			delete_transient( self::get_cache_key( $post_id ) );
		}	

		public static function get_cache_key( $post_id ){
			return sprintf( 'nictitate_page_builder_cache_%s', $post_id );
		}		
	}

	new Nictitate_Lite_II_Builder();

}