<?php

$layout = Nictitate_Lite_II_Builder_Layout::get_layout_ultimate();
Nictitate_Lite_II_Builder::print_page( get_queried_object_id(), $layout );