<?php

#FUNCTION.
require get_template_directory() . '/inc/utility.php';
require get_template_directory() . '/inc/customize.php';
require get_template_directory() . '/inc/config.php';
require get_template_directory() . '/inc/resource.php';

#OPTIONS.
require get_template_directory() . '/inc/options.php';

#LAYOUT.
require get_template_directory() . '/inc/sidebar.php';
require get_template_directory() . '/inc/layout.php';
require get_template_directory() . '/inc/metabox.php';

#PLUGINS.
require get_template_directory() . '/inc/plugin.php';

#PAGE-BUILDER.
require get_template_directory() . '/page-builder/init.php';