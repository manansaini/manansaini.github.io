/**
 * http://kopatheme.com
 * Copyright (c) 2015 Kopatheme
 *
 * Licensed under the GPL license:
 *  http://www.gnu.org/licenses/gpl.html
 **/

'use strict';

var google_maps_01;
var google_maps_02;

jQuery( window ).load( function($) {
    k_map();
});

/**
 * @description Google map
 * @return 
 */
function k_map(){
    if (jQuery('.k-map').length > 0) {

        if (jQuery('.k-map-contact-form .k-map').length > 0) {
            jQuery('.k-map-contact-form .k-map').each(function(){
                var id = jQuery(this).attr('id');
                
                google_maps_02 = new GMaps({
                    div: '#'+id,
                    lat: jQuery(this).attr('data-latitude'),
                    lng: jQuery(this).attr('data-longtitude')
                });

                google_maps_02.addMarker({
                    lat: jQuery(this).attr('data-latitude'),
                    lng: jQuery(this).attr('data-longtitude'),
                    title: jQuery(this).attr('data-location')
                });
            });
            
        }

        if (jQuery('.k-widget-map .k-map').length > 0) {
            jQuery('.k-widget-map .k-map').each(function(){                
                var id = jQuery(this).attr('id');
                google_maps_01 = new GMaps({
                    div: '#'+id,
                    lat: jQuery(this).attr('data-latitude'),
                    lng: jQuery(this).attr('data-longtitude')
                });

                google_maps_01.addMarker({
                    lat: jQuery(this).attr('data-latitude'),
                    lng: jQuery(this).attr('data-longtitude'),
                    title: jQuery(this).attr('data-location')
                });

            });
            
        }
    }
}