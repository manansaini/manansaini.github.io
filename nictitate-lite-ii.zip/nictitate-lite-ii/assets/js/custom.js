/**
 * http://kopatheme.com
 * Copyright (c) 2015 Kopatheme
 *
 * Licensed under the GPL license:
 *  http://www.gnu.org/licenses/gpl.html
 **/

'use strict';
/**
 *   1- Desktop menu
 *   2- Mobile menu
 *   3- Accordion, toggle
 *   4- Carousel
 *   5- Hover div effect
 *   6- Google map
 *   7- Masonry layout
 *   8- Quantity product
 *   9- sync carousel
 *   8- Gallery image flick
 *   9- Slider animation
 *   10- Search bar
 *   11- Validate form
 *   12- Responsive tabs
 *   13- Scroll animation
 *-----------------------------------------------------------------
 **/

jQuery(document).ready(function($) {
    k_menu();
    k_mobile_menu();
    k_accordion();
    k_owl_carousel();
    k_hover_div();    
    k_masonry();
    k_quantity();
    k_sync_carousel();
    k_flick();
    k_search_bar();
    k_slider_animation();
    k_validate();
    k_tabs();
    k_scroll_animation();
    nictitate_popup();
});

jQuery(window).load(function(){
   nictitate_load_more_blog_timeline();
   nictitate_load_more_blog_masonry(); 
});

jQuery(document).ajaxComplete( function() {    
    nictitate_popup();
});

function k_menu(){
	if (jQuery('.sf-menu').length) {
        jQuery('.sf-menu').superfish();
    }
}

function k_mobile_menu(){
	if (jQuery('#mobile-menu').length) {
        jQuery('#mobile-menu').mmenu();
    }
}

function k_accordion(){
	jQuery('.k-toggle .panel-heading').on('click', function(){
		jQuery(this).parent().find('.collapse').collapse('toggle');
		jQuery(this).find('a').toggleClass('collapsed');
	});

	jQuery('.k-accordion .panel-heading').on('click', function(){	
		
		jQuery(this).closest('.k-accordion').find('.collapse').collapse('hide');
		jQuery(this).parent().find('.collapse').collapse('toggle');		

		jQuery(this).closest('.k-accordion').find('.panel-heading').not(this).find('a').addClass('collapsed');
		jQuery(this).find('a').toggleClass('collapsed');

        
	});
    if(jQuery('.k-accordion').length){
        var panel_titles = jQuery('.k-accordion .panel-title a');
        panel_titles.addClass("collapsed");
        jQuery('.panel-heading.active').find(panel_titles).removeClass("collapsed");
        panel_titles.click(function(){
            jQuery(this).closest('.k-accordion').find('.panel-heading').removeClass('active');
            var pn_heading = jQuery(this).parents('.panel-heading');
            if (jQuery(this).hasClass('collapsed')) {
                pn_heading.addClass('active');
            } else {
                pn_heading.removeClass('active');
            }
        });
    }
}

function k_owl_carousel(){
	if (jQuery('.owl-carousel').length) {
        if (jQuery('.k-widget-logo .owl-carousel').length) {
            jQuery('.k-widget-logo .owl-carousel').owlCarousel({
                items:5,
                slideSpeed:500,
                pagination:false,
                navigation:true,
                navigationText:['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']

            });
        }

        if (jQuery('.k-widget-related-product .owl-carousel').length) {
            jQuery('.k-widget-related-product .owl-carousel').owlCarousel({
                items:4,
                slideSpeed:500,
                pagination:false,
                navigation:true,
                navigationText:['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']

            });
        }

        if (jQuery('.k-widget-testi .owl-carousel').length) {
            jQuery('.k-widget-testi .owl-carousel').owlCarousel({
                singleItem:true,
                slideSpeed:500,
            });
        }

        if (jQuery('.k-widget-post-carousel .owl-carousel').length) {
            jQuery('.k-widget-post-carousel .owl-carousel').owlCarousel({
                items:2,
                itemsDesktop:[1366,2],
                itemsDesktopSmall:[1000,1],
                slideSpeed:500,
                pagination:false,
                navigation:true,
                scrollPerPage:true,
                navigationText:['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']

            });
        }

        if (jQuery('.single-carousel').length) {
            jQuery('.single-carousel').owlCarousel({
                singleItem:true,
                slideSpeed:500,
                pagination:false,
                navigation:true,
                navigationText:['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
                autoHeight:true,
                afterInit : function(){
                    if (jQuery('.list-blog-post-timeline').length) {
                        setTimeout(function(){
                            jQuery('.list-blog-post-timeline').masonry().masonry('layout');
                        },1000);
                    }

                    if (jQuery('.list-blog-post-masonry').length) {
                        setTimeout(function(){
                            jQuery('.list-blog-post-masonry').masonry().masonry('layout');
                        },1000);
                    }
                },
                afterUpdate : function(){
                    if (jQuery('.list-blog-post-timeline').length) {
                        setTimeout(function(){
                            jQuery('.list-blog-post-timeline').masonry().masonry('layout');
                        },1000);
                    }

                    if (jQuery('.list-blog-post-masonry').length) {
                        setTimeout(function(){
                            jQuery('.list-blog-post-masonry').masonry().masonry('layout');
                        },1000);
                    }
                }
            });
        }
	}
}

function k_hover_div(){	
	if (jQuery('.hover_div').length) {
        var $container = jQuery('.hover_div');
        $container.imagesLoaded(function(){
            $container.masonry({
                itemSelector : '.item',
                columnWidth: '.item-sm'
            });
        });
	}	
}

function k_masonry(){

	if (jQuery('.masonry-container').length) {
        if (jQuery('.list-blog-post-masonry').length) {
            var $container = jQuery('.list-blog-post-masonry');
            $container.imagesLoaded(function(){
                $container.masonry({
                    itemSelector : '.item',
                    columnWidth: '.item'
                });
            });
        }

        if (jQuery('.list-blog-post-timeline').length) {
            var $container2 = jQuery('.list-blog-post-timeline');
            var $grid = $container2.imagesLoaded(function(){
                $grid.masonry({
                    itemSelector : '.item',
                    columnWidth: '.item'
                });
            });

            $grid.on('layoutComplete').done(k_re_layout);
        }

        if (jQuery('.k-widget-portfolio-filter .masonry-items').length) {

            var $container3 = jQuery('.k-widget-portfolio-filter .masonry-items');
            var masonryOptions = {
                itemSelector : '.item.show',
                columnWidth: '.item.show'
            };

            $container3.imagesLoaded(function(){
                var $grid = $container3.masonry( masonryOptions);
                var $filters = jQuery('.k-widget-portfolio-filter .masonry-filter a');

                $filters.on('click', function(event){

                    event.preventDefault();
                    $filters.removeClass('active');
                    jQuery(this).addClass('active');
                    var $filter_val = jQuery(this).data('val');
                    $container3.find('.item').each(function(){

                        var $item_val = jQuery(this).data('val').toString().split(',');
                        var a = $item_val.indexOf($filter_val.toString()) > -1;

                        if ($filter_val == "*") {
                            jQuery(this).removeClass('hide');
                            jQuery(this).addClass('show');
                        } else {
                            if ( a == true) {
                                jQuery(this).removeClass('hide');
                                jQuery(this).addClass('show');
                            } else {
                                jQuery(this).removeClass('show');
                                jQuery(this).addClass('hide');
                            }
                        }
                    });

                    $container3.masonry('layout');
                });            
            });

            jQuery('.k-widget-portfolio-filter').on('click', '.read-more-portfolio', function(event){
                event.preventDefault();

                var button      = jQuery(this);                

                if( !button.hasClass('in-process') ){
                    
                    var button_next = button.next();

                    jQuery.ajax({
                        url: button_next.attr('href'),
                        data: {},
                        dataType: 'html',
                        type: 'POST',
                        async: false,
                        beforeSend: function( xhr ) {        
                            button.addClass('in-process');
                            button.text(nictitate_lite_ii.i18n.LOADING);
                        },
                        success: function(data, textStatus, jqXHR) {
                            var newItems = jQuery(data).find('.k-widget-portfolio-filter .masonry-items .item');

                            if( newItems.length ){

                                jQuery(newItems).imagesLoaded(function() {                            
                                    jQuery.each(newItems, function(){
                                        jQuery('.k-widget-portfolio-filter .masonry-items').append( jQuery(this) ).masonry( 'appended', jQuery(this) );
                                    });
                                }); 

                                var new_button_next = jQuery(data).find('.read-more-portfolio').next();
                                if( new_button_next.length ){                            
                                    button_next.attr( 'href', new_button_next.attr('href') );
                                    button.removeClass( 'in-process' );
                                }else{
                                   button.remove();
                                }                            

                            } else {
                                button.hide();
                            }
                        },
                        complete  : function() {     
                            if( button.length ){
                                button.text(nictitate_lite_ii.i18n.LOAD_MORE);
                            }
                        },
                    });

                }
            });

        }

        if (jQuery('.k-list-product').length) {
            var $container4 = jQuery('.k-list-product');
            $container4.imagesLoaded(function(){
                $container4.masonry({
                    itemSelector : '.col-md-4',
                    columnWidth: '.col-md-4'
                });
            });
        }
	}		
}

function k_re_layout() {
	var $container = jQuery('.list-blog-post-timeline');
	$container.find('.item').each(function(){
		var $this = jQuery(this);
		var position = jQuery(this).position();
		if (position.left == 0) {
			$this.removeClass('item-right').addClass('item-left');
		} else {
			$this.removeClass('item-left').addClass('item-right');
		}
	});
}

function k_quantity(){
	jQuery(".entry-product .quantity .qty").keydown(function (e) {
        if (jQuery.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
            (e.keyCode == 65 && e.ctrlKey === true) ||
            (e.keyCode == 67 && e.ctrlKey === true) ||
            (e.keyCode == 88 && e.ctrlKey === true) ||
            (e.keyCode >= 35 && e.keyCode <= 39)) 
        {
            return;
        }
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

	jQuery('.entry-product .quantity .qty-minus').on('click', function(){
		var $this = jQuery(this).parent().find('.qty');
		var $old_val = parseInt($this.val());
		var $new_val = $old_val - 1;
		if ($new_val < 1) {
			$new_val = 1;			
		}
		$this.val($new_val);
		
	});

	jQuery('.entry-product .quantity .qty-plus').on('click', function(){
		var $this = jQuery(this).parent().find('.qty');
		var $old_val = parseInt($this.val());
		var $new_val = $old_val + 1;
		$this.val($new_val);
	});
}

function k_sync_carousel(){

	var sync1 = jQuery("#sync1");
  	var sync2 = jQuery("#sync2");
 	
 	if (sync1.length) {
         sync1.owlCarousel({
             singleItem : true,
             slideSpeed : 500,
             pagination:false,
             responsiveRefreshRate : 200,
             autoHeight:true,
             addClassActive:true,
             lazyLoad : true,
             afterInit:function(){
                 k_zoom();
             },
             afterAction:function(){
                 var current = this.currentItem;
                 jQuery("#sync2")
                     .find(".owl-item")
                     .removeClass("synced")
                     .eq(current)
                     .addClass("synced")
                 if(jQuery("#sync2").data("owlCarousel") !== undefined){
                     k_center(current)
                 }
                 jQuery('.zoomContainer').remove();
                 k_zoom();
             }
         });

         sync2.owlCarousel({
             items : 3,
             responsiveRefreshRate : 100,
             pagination:false,
             navigation:true,
             lazyLoad : true,
             navigationText:['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>'],
             afterInit : function(el){
                 el.find(".owl-item").eq(0).addClass("synced");
             }
         });

         jQuery("#sync2").on("click", ".owl-item", function(e){
             e.preventDefault();
             var number = jQuery(this).data("owlItem");
             sync1.trigger("owl.goTo",number);
         });
 	}
}

function k_center(number){
    var sync2visible = sync2.data("owlCarousel").owl.visibleItems;
    var num = number;
    var found = false;
    for(var i in sync2visible){
      if(num === sync2visible[i]){
        var found = true;
      }
    }
 
    if(found===false){
      if(num>sync2visible[sync2visible.length-1]){
        sync2.trigger("owl.goTo", num - sync2visible.length+2)
      }else{
        if(num - 1 === -1){
          num = 0;
        }
        sync2.trigger("owl.goTo", num);
      }
    } else if(num === sync2visible[sync2visible.length-1]){
      sync2.trigger("owl.goTo", sync2visible[1])
    } else if(num === sync2visible[0]){
      sync2.trigger("owl.goTo", num-1)
    }    
}

function k_zoom(){
	setTimeout(function(){
		jQuery("#sync1").find('.active img').elevateZoom({
    		responsive:true,
    		scrollZoom:true,
    		zoomWindowWidth:500,
    		zoomWindowHeight:500,
    		borderSize:1,
    		borderColour:'#e5e5e5',
    		lensColour:'#0c86c6',
    		lensOpacity:0.6,
    		zoomWindowPosition: "product-zoom"
    	});
	},500);	
}

function k_flick(){
	if (jQuery('.flickr-wrap ul').length) {
        var $this = jQuery('.flickr-wrap'),
        flickrID = $this.data('id'),
        limitItems = parseInt($this.data('limit'));

        jQuery('.flickr-wrap ul').jflickrfeed({
            limit: limitItems,
            qstrings: {
                id: flickrID
            },
            itemTemplate: '<li class="flickr-badge-image">' + '<a target="blank" href="{{link}}" title="{{title}}" class="imgLiquid" style="width:79px; height:79px;">' + '<img src="{{image_m}}" alt="{{title}}"  />' + '<i class="fa fa-plus"></i></a>' + '</li>'
        }, function(data) {
            jQuery('.flickr-wrap .imgLiquid').imgLiquid();
        });
    }
}

function k_slider_animation(){
	if (jQuery('.k-widget-slider-animation').length) {
        jQuery('.slider').fractionSlider({
            'fullWidth': 			true,
            'controls': 			true,
            'responsive': 			true,
            'dimensions': 			"1366,500",
            'increase': 			false,
            'pauseOnHover': 		true,
            'autoChange': 			false,
            'slideEndAnimation': 	true
        });
	}
}

function k_search_bar(){
	if (jQuery('.sb-search').length) {
        new UISearch( document.getElementById('sb-search'));
    }
}

function k_validate(){
    if (jQuery('.k-map-contact-form form').length || jQuery('.k-widget-contact-form form').length || jQuery('.comment-form').length) {
        
        jQuery('.k-map-contact-form form').validate({
            rules: {
                author: {
                    required: true,
                    minlength: 4
                },
                email: {
                    required: true,
                    email: true
                },
                subject: {
                    required: true,
                    minlength: 10
                },
                comment: {
                    required: true,
                    minlength: 10
                }
            },
            messages: {
                author: {
                    required: nictitate_lite_ii.i18n.validate.name.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.name.MINLENGTH)
                },
                email: {
                    required: nictitate_lite_ii.i18n.validate.email.REQUIRED,
                    email: nictitate_lite_ii.i18n.validate.email.EMAIL
                },
                subject: {
                    required: nictitate_lite_ii.i18n.validate.subject.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.subject.MINLENGTH)
                },
                comment: {
                    required: nictitate_lite_ii.i18n.validate.message.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.message.MINLENGTH)
                }
            },
            submitHandler: function(form) {
                    jQuery('#submit-contact').attr("value", nictitate.form.SENDING);
                    jQuery(form).ajaxSubmit({
                        success: function(responseText, statusText, xhr, $form) {
                            jQuery('#response').html(responseText).hide().slideDown("fast");
                            jQuery('#submit-contact').attr("value", nictitate.form.SUBMIT);
                            jQuery(form).find('[name=name]').val('');
                            jQuery(form).find('[name=email]').val('');
                            jQuery(form).find('[name=subject]').val('');
                            jQuery(form).find('[name=message]').val('');
                        }
                    });
                    return false;
                }
        });

        jQuery(' .k-widget-contact-form form').validate({
            rules: {
                author: {
                    required: true,
                    minlength: 4
                },
                email: {
                    required: true,
                    email: true
                },
                subject: {
                    required: true,
                    minlength: 10
                },
                comment: {
                    required: true,
                    minlength: 10
                }
            },
            messages: {
                author: {
                    required: nictitate_lite_ii.i18n.validate.name.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.name.MINLENGTH)
                },
                email: {
                    required: nictitate_lite_ii.i18n.validate.email.REQUIRED,
                    email: nictitate_lite_ii.i18n.validate.email.EMAIL
                },
                subject: {
                    required: nictitate_lite_ii.i18n.validate.subject.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.subject.MINLENGTH)
                },
                comment: {
                    required: nictitate_lite_ii.i18n.validate.message.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.message.MINLENGTH)
                }
            },
            submitHandler: function(form) {
                jQuery('#submit-contact').attr("value", nictitate.form.SENDING);
                jQuery(form).ajaxSubmit({
                    success: function(responseText, statusText, xhr, $form) {
                        jQuery('#response').html(responseText).hide().slideDown("fast");
                        jQuery('#submit-contact').attr("value", nictitate.form.SUBMIT);
                        jQuery(form).find('[name=name]').val('');
                        jQuery(form).find('[name=email]').val('');
                        jQuery(form).find('[name=subject]').val('');
                        jQuery(form).find('[name=message]').val('');
                    }
                });
                return false;
            }
        });

        jQuery(' .comment-form').validate({
            rules: {
                author: {
                    required: true,
                    minlength: 4
                },
                email: {
                    required: true,
                    email: true
                },
                subject: {
                    required: true,
                    minlength: 10
                },
                comment: {
                    required: true,
                    minlength: 10
                }
            },
            messages: {
                author: {
                    required: nictitate_lite_ii.i18n.validate.name.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.name.MINLENGTH)
                },
                email: {
                    required: nictitate_lite_ii.i18n.validate.email.REQUIRED,
                    email: nictitate_lite_ii.i18n.validate.email.EMAIL
                },
                subject: {
                    required: nictitate_lite_ii.i18n.validate.subject.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.subject.MINLENGTH)
                },
                comment: {
                    required: nictitate_lite_ii.i18n.validate.message.REQUIRED,
                    minlength: jQuery.format(nictitate_lite_ii.i18n.validate.message.MINLENGTH)
                }
            },
        });
    }
}

function k_tabs() {
	if (jQuery('.k-tabs.style-3').length) {		
    	k_responsive_tabs();
    	jQuery( window ).resize( function () {
			k_responsive_tabs();
		});		
    }
}

function k_responsive_tabs(){
	jQuery('.k-tabs.style-3').each(function(){
		var x = Math.floor((Math.random() * 100) + 1);
		var $htmlCollapse = '<div class="panel-group" id="accordion'+ x +'" role="tablist" aria-multiselectable="true">';
		var $parent = jQuery(this);
		var $childrenNavTabs = jQuery(this).find('.nav-tabs li');
		var $childrenNavContent = jQuery(this).find('.tab-content .tab-pane');
		var windowWidth = jQuery(window).width();

		if (windowWidth < 1024) {
    		
    		$childrenNavTabs.each(function(){
    			var $thisChildrenNavTabs = jQuery(this);
    			$htmlCollapse += '<div class="panel panel-default">';
                $htmlCollapse += '<div class="panel-heading" role="tab" id="heading'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'">';
                $htmlCollapse += '<h4 class="panel-title">';

                if ($thisChildrenNavTabs.hasClass('active')) {
                	$htmlCollapse += '<a role="button" data-toggle="collapse" data-parent="#accordion'+ x +'" href="#collapse'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'" aria-expanded="true" aria-controls="collapse'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'">';
                } else {
                	$htmlCollapse += '<a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion'+ x +'" href="#collapse'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'" aria-expanded="true" aria-controls="collapse'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'">';
                }

                $htmlCollapse += jQuery(this).find('a').html();
                $htmlCollapse += '</a>';
                $htmlCollapse += '</h4>';
                $htmlCollapse += '</div>';
                  
                $childrenNavContent.each(function(){
                	if ($thisChildrenNavTabs.find('a').attr('aria-controls') == jQuery(this).attr('id')) {
                		if ($thisChildrenNavTabs.hasClass('active')) {
                			$htmlCollapse += '<div id="collapse'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'">';
                		} else {
                			$htmlCollapse += '<div id="collapse'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading'+ $thisChildrenNavTabs.find('a').attr('aria-controls') +'">';
                		}
                		
                        $htmlCollapse += '<div class="panel-body">';
                        $htmlCollapse += jQuery(this).html();
                        $htmlCollapse += '</div>';
                        $htmlCollapse += '</div>';
                	}
                });                        

    			$htmlCollapse += '</div>';
    		});

			$htmlCollapse += '</div>';

			$parent.find('> .nav-tabs').hide();
			$parent.find('> .tab-content').hide();

			if ($parent.find('> .panel-group').length < 1) {
				$parent.append($htmlCollapse);
			} else {
				$parent.find('> .panel-group').show();
			}

		} else {
			$parent.find('> .nav-tabs').show();
			$parent.find('> .tab-content').show();
			if ($parent.find('> .panel-group').length) {
				$parent.find('> .panel-group').hide();
			}
		}
	});
}

function k_scroll_animation() {
    jQuery(window).on("scroll",function() {
        var $scrollTop = jQuery(this);
        jQuery('.k-widget-number').each(function(){
            var $this = jQuery(this);
            var hT = $this.offset().top,
                hH = $this.outerHeight(),
                wH = jQuery(window).height(),
                wS = $scrollTop.scrollTop();
            if (wS > (hT+hH-wH)){
                k_count();
            }
        });

    });

    jQuery(window).scroll(function() {
        var $scrollTop = jQuery(this);
        jQuery('.k-progress').each(function(){
            var $this = jQuery(this);
            var hT = $this.offset().top,
                hH = $this.outerHeight(),
                wH = jQuery(window).height(),
                wS = $scrollTop.scrollTop();
            if (wS > (hT+hH-wH)){
                k_progress_animation();
            }
        });

    });
}

function k_count () {
    var items = jQuery('.k-widget-number .item');
    if(items.length) {
    	jQuery.each(items,function(){

    		var $this = jQuery(this).find('.item-number');
    		var $id = $this.attr("id");
    		var $end = parseInt( $this.data("number"), 10);
            var $start = parseInt( $this.text(), 10);
    		if ( $end  > $start ) {
    			var $count = new CountUp($id, 0, $end, 0 ,2);
    			$count.start();
    		};		
    	});
    }
}

function k_progress_animation (){
	jQuery('.k-progress').each(function(){
		var $progress_bar = jQuery(this).find('.progress-bar');
		var $this = jQuery(this).find('.progress-bar  i');
		var $id = $this.attr("id");
		var $number = $this.data("number");

		if ($number > $this.text() && $id != null) {
			var $count = new CountUp($id, 0, $number,0 ,2);
			$count.start(function() {
				var myWidth = $this.text();				
			});
		};		
		$progress_bar.width($number + '%');
	});
}

function nictitate_load_more_blog_timeline () {
    
    var block_btn_loadmore = jQuery( '#nictitate_blog_timeline .k-pagination' );

    if( block_btn_loadmore.length ){

        block_btn_loadmore.on('click', '.read-more', function(event){
            event.preventDefault();
            var btn_loadmore = jQuery(this);
            var link_loadmore = block_btn_loadmore.find('a');

            if( link_loadmore.length && !btn_loadmore.hasClass('in_process') ){

                var ajax_url = link_loadmore.attr('href');

                jQuery.ajax({
                    type: 'POST',
                    url: ajax_url,
                    data_Type: 'html',
                    async: false,
                    data : {},
                    beforeSend: function(XMLHttpRequest, settings) { 
                        btn_loadmore.addClass('in_process'); 
                    },
                    complete: function(XMLHttpRequest, textStatus) {
                        btn_loadmore.removeClass('in_process'); 
                    },
                    success: function(data) {

                        var elements = jQuery(data).find('.list-blog-post-timeline .item');
                        if( elements.length ){
                            elements.imagesLoaded( function() {
                                jQuery('ul.list-blog-post-timeline').append( elements ).masonry( 'appended', elements );                                
                                k_re_layout();
                                var next_link_loadmore = jQuery(data).find('.k-pagination a');
                                if( next_link_loadmore.length ){
                                    link_loadmore.attr( 'href', next_link_loadmore.attr('href') );
                                }else{
                                    block_btn_loadmore.remove();
                                }

                            });
                        }
     
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        
                    }
                });

            }

        });
    }
}

function nictitate_load_more_blog_masonry () {
    var block_btn_loadmore = jQuery( '#nictitate_blog_masonry .k-pagination' );

    if( block_btn_loadmore.length ){

        block_btn_loadmore.on('click', '.read-more', function(event){
            event.preventDefault();
            var btn_loadmore = jQuery(this);
            var link_loadmore = block_btn_loadmore.find('a');

            if( link_loadmore.length && !btn_loadmore.hasClass('in_process') ){

                var ajax_url = link_loadmore.attr('href');

                jQuery.ajax({
                    type: 'POST',
                    url: ajax_url,
                    data_Type: 'html',
                    async: false,
                    data : {},
                    beforeSend: function(XMLHttpRequest, settings) { 
                        btn_loadmore.addClass('in_process'); 
                    },
                    complete: function(XMLHttpRequest, textStatus) {
                        btn_loadmore.removeClass('in_process'); 
                    },
                    success: function(data) {

                        var elements = jQuery(data).find('.list-blog-post-masonry .item');
                        if( elements.length ){
                            elements.imagesLoaded( function() {
                                jQuery('ul.list-blog-post-masonry').append( elements ).masonry( 'appended', elements );                                

                                var next_link_loadmore = jQuery(data).find('.k-pagination a');
                                if( next_link_loadmore.length ){
                                    link_loadmore.attr( 'href', next_link_loadmore.attr('href') );
                                }else{
                                    block_btn_loadmore.remove();
                                }

                            });
                        }
     
                    },
                    error: function (XMLHttpRequest, textStatus, errorThrown) {
                        
                    }
                });

            }

        });
    }
}

function nictitate_popup(){
    jQuery('#nictitate-portfolio-archive').magnificPopup({
        delegate: '.nictitate-gallery-item',
        type: 'image',
        gallery: {
          enabled:true
        }
    });    
}