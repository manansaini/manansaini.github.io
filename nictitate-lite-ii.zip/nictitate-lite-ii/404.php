<?php
get_header();
$layout_id = nictitate_lite_ii_get_template_setting();
$template  = apply_filters( 'nictitate_lite_ii_get_404_template', sprintf( 'template/404/%s', $layout_id ) );
get_template_part( $template );
get_footer();