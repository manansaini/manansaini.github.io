            </div>
            <?php
            $nictitate_lite_ii_sb_f1    = apply_filters( 'nictitate_lite_ii_get_sidebar_by_position', 'sb_footer_1', 'pos_footer_1' );
            $nictitate_lite_ii_sb_f2    = apply_filters( 'nictitate_lite_ii_get_sidebar_by_position', 'sb_footer_2', 'pos_footer_2' );
            $nictitate_lite_ii_sb_f3    = apply_filters( 'nictitate_lite_ii_get_sidebar_by_position', 'sb_footer_3', 'pos_footer_3' );
            $nictitate_lite_ii_sb_f4    = apply_filters( 'nictitate_lite_ii_get_sidebar_by_position', 'sb_footer_4', 'pos_footer_4' );
            $nictitate_lite_ii_sb_f5    = apply_filters( 'nictitate_lite_ii_get_sidebar_by_position', 'sb_footer_5', 'pos_footer_5' );
            $footer_use_sidebar = (int) get_theme_mod( 'footer_use_sidebar', 1 );
            $footer_use_social  = (int) get_theme_mod( 'footer_use_social', 1 );
            if ( is_singular() ) {
                global $post;
                $is_hide_footer_socials = (int) get_post_meta( $post->ID, 'nictitate_lite_ii_is_hide_footer_socials', true );
                if ( $is_hide_footer_socials ) {
                    $footer_use_social = false;
                }            
            }
            ?>
    		<div class="footer-page">
                <?php if ( 1 == $footer_use_sidebar ) : ?>
                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f1 ) || is_active_sidebar( $nictitate_lite_ii_sb_f2 ) ) : ?>
                        <div class="top-footer-page">
                            <div class="container">
                                <div class="row">
                                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f1 ) ) : ?>
                                        <div class="col-md-4 col-xs-12 widget-area-2">
                                            <?php dynamic_sidebar( $nictitate_lite_ii_sb_f1 ); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f2 ) ) : ?>
                                        <div class="col-md-8 col-xs-12 widget-area-3">
                                            <?php dynamic_sidebar( $nictitate_lite_ii_sb_f2 ); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f3 ) || is_active_sidebar( $nictitate_lite_ii_sb_f4 ) || is_active_sidebar( $nictitate_lite_ii_sb_f5 ) ) : ?>
                        <div class="middle-footer-page">
                            <div class="container">
                                <div class="row">
                                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f3 ) ) : ?>
                                        <div class="col-md-4 col-sm-6 col-xs-12 widget-area-4">
                                            <?php dynamic_sidebar( $nictitate_lite_ii_sb_f3 ); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f4 ) ) : ?>
                                        <div class="col-md-4 col-sm-6 col-xs-12 widget-area-5">
                                            <?php dynamic_sidebar( $nictitate_lite_ii_sb_f4 ); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php if ( is_active_sidebar( $nictitate_lite_ii_sb_f5 ) ) : ?>
                                        <div class="col-md-4 col-xs-12 widget-area-6">
                                            <?php dynamic_sidebar( $nictitate_lite_ii_sb_f5 ); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="bottom-footer-page">
                    <div class="container">
                        <?php if ( $nictitate_copyright = get_theme_mod( 'copyright', '' ) ) : ?>
                            <div class="copyright"><span><?php echo wp_kses( $nictitate_copyright, nictitate_lite_ii_get_allowed_tags() ); ?></span></div>
                        <?php endif; ?>
                        <?php 
                            if( $footer_use_social ) :
                                get_template_part( 'template/footer/social', 'links' );
                            endif; 
                        ?>
                    </div>
                </div>
            </div>
        </div>
        <?php wp_footer(); ?>
    </body>
</html>