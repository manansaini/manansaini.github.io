<div id="nictitate_blog_masonry" class="container">  
	<?php if( have_posts() ) : 
	global $wp_query;
	$excerpt_length = (int) get_theme_mod( 'blog_excerpt_length', '10' );
	if ( ! isset( $excerpt_length ) || empty( $excerpt_length ) ) {
		$excerpt_length = 10;
	}
	$GLOBALS['nictitate_lite_ii_excerpt_length'] = (int) $excerpt_length;
	add_filter( 'excerpt_length', 'nictitate_lite_ii_set_excerpt_length' );
	$found_posts = $wp_query->found_posts;
	$post_page   = get_option( 'posts_per_page' ); 
	?>          
	<ul class="list-blog-post list-blog-post-masonry masonry-container row" data-post="<?php echo esc_attr( $found_posts ); ?>" data-post-page="<?php echo esc_attr( $post_page ); ?>">
	<?php while( have_posts() ) : the_post(); 
			global $post;
			$post_id     = $post->ID;
			$author_id   = $post->post_author;
			$post_format = get_post_format();
			$post_format = ( false === $post_format || 'image' === $post_format || 'aside' === $post_format || 'status' === $post_format || 'link' === $post_format || 'chat' === $post_format ) ? 'standard' : $post_format;
	?>
		<li class="item col-md-3 col-sm-6 col-xs-12">
			<?php if( 'quote' != $post_format ): ?>
			<div class="item-inner">
				<?php get_template_part( 'template/archive/parts/post-thumbnail/type', $post_format ); ?>
				<div class="item-content">
					<h4 class="item-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
					<?php get_template_part( 'template/archive/parts/metadata-2' ); ?>
					<?php the_excerpt(); ?>
					<?php get_template_part( 'template/archive/parts/metadata-3' ); ?>
				</div>
			</div>
			<?php else: ?>
				<?php get_template_part( 'template/archive/parts/post-thumbnail/type', $post_format ); ?>
			<?php endif; ?>
		</li>
	<?php 
	endwhile; 
	remove_filter( 'excerpt_length', 'nictitate_lite_ii_set_excerpt_length' ); ?>
	</ul>
	<?php if ( $found_posts > $post_page ) : ?>
	<div class="k-pagination text-center">
		<?php next_posts_link(false); ?>
		<span class="read-more read-more-border"><?php echo esc_html__( 'load more...', 'nictitate-lite-ii'); ?></span>
	</div> 
	<?php endif; ?>
	<?php else: ?>
		<?php printf( '<blockquote>%1$s</blockquote>', esc_html__( 'Nothing Found...', 'nictitate-lite-ii' ) ); ?>
	<?php endif; ?>
</div>