<?php
$blog_read_more = (int) get_theme_mod( 'blog_read_more', '1' );
if( 1 == $blog_read_more ):
?>
<a href="<?php the_permalink(); ?>" class="read-more read-more-border"><?php echo esc_html__( 'read more', 'nictitate-lite-ii' ); ?></a>
<?php
endif;