<?php
if ( $custom_html = get_post_meta( get_the_ID(), 'nictitate_toolkit_ii_custom', true ) ) :
?>
<div class="item-thumb">
    <div class="embed-responsive embed-responsive-16by9">
		<?php echo apply_filters( 'the_content', $custom_html ); ?>
    </div>
</div>
<?php
endif;
