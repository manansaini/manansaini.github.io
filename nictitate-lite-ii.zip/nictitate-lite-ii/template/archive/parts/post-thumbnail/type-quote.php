<?php
$data = wp_parse_args( (array) get_post_meta( get_the_ID(), 'nictitate_toolkit_ii_quote', true ), array( 'quote' => null, 'author' => null ) );
extract( $data );

if ( $quote ) :
	?>
<div class="item-content k_blog_quote">
    <blockquote>
		<p><?php echo wp_kses( $quote, nictitate_lite_ii_get_allowed_tags() ); ?></p>
		<?php if ( $author ) : ?>       
			<small><?php echo wp_kses( $author, nictitate_lite_ii_get_allowed_tags() ); ?></small>
		<?php endif;?>
    </blockquote>
</div>
<?php
endif;