<?php
$layout_id          = nictitate_lite_ii_get_template_setting();
$post_format        = get_post_format();
$post_format        = ( false === $post_format || 'image' === $post_format || 'aside' === $post_format || 'status' === $post_format || 'link' === $post_format || 'chat' === $post_format ) ? 'standard' : $post_format;
$show_featured_img  = get_theme_mod ( 'blog_featured_img', 'show_placeholdit' ); 
$size_default_thumb = '852x391';
$size_thumb         = 'nictitate-'.$layout_id;
$class              = (is_singular('post')) ? ' entry-thumb item-thumb' : ' item-thumb';

switch ($layout_id) {
	case 'blog-default':
	case 'single-default':
		$size_default_thumb = '852x391';
		break;
	case 'blog-timeline':
		$size_default_thumb = '418x240';
		break;
	case 'blog-timeline-2':
		$size_default_thumb = '880x292';
		break;
	case 'blog-masonry':
		$size_default_thumb = '264x189';
		break;
	default:
		$size_default_thumb = '852x391';
		break;
}
?>
<div class="<?php echo esc_attr($class); ?>">
	<a href="<?php the_permalink(); ?>">
	<?php if( has_post_thumbnail() ): ?>
		<?php the_post_thumbnail( $size_thumb, array('title' => get_the_title(), 'alt' => '') ); ?>
	<?php else: ?>
		<?php if(  'show_placeholdit' == $show_featured_img ): ?>
		<img src="http://placehold.it/<?php echo esc_attr( $size_default_thumb ); ?>" alt="">
		<?php endif; ?>
	<?php endif; ?>
	</a>
	<?php get_template_part( 'template/archive/parts/metadata' ); ?>
	<?php if( is_sticky() && 'standard' == $post_format ): ?>
		<i class=" icon-sticky"><i class="fa fa-bolt"></i></i>
	<?php endif; ?>
</div>