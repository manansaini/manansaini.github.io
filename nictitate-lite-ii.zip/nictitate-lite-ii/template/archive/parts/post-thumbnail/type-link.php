
<?php
$excerpt_length = (int)get_theme_mod( 'blog_excerpt_length', '10' );
if ( ! isset($excerpt_length) || empty($excerpt_length) ) {
	$excerpt_length = 10;
}
$GLOBALS['nictitate_lite_ii_excerpt_length'] = (int) $excerpt_length;
add_filter('excerpt_length', 'nictitate_lite_ii_set_excerpt_length');
?>
<div class="item-content k_post_link">
	<div class="k-link">
		<a class="k-link-first" href="<?php the_permalink(); ?>" target="_blank"><?php the_excerpt(); ?></a>
		<?php if ( $linkto = get_post_meta( get_the_ID(), 'nictitate_toolkit_ii_linkto', true ) ) : ?>
		<a href="<?php echo esc_url($linkto ); ?>"><?php echo esc_url($linkto); ?></a>
		<?php endif; ?>
	</div>
	<?php remove_filter('excerpt_length', 'nictitate_lite_ii_set_excerpt_length'); ?>
	<?php get_template_part('template/archive/parts/metadata-3'); ?>                                   
</div>