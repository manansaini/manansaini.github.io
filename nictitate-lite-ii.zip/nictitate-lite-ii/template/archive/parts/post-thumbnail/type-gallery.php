<?php
$layout_id = nictitate_lite_ii_get_template_setting();
$layout_id = ('blog-timeline' == $layout_id) ? $layout_id.'-gallery' : $layout_id;
$size_thumb = 'nictitate-'.$layout_id;
if ( $gallery = get_post_meta( get_the_ID(), 'nictitate_toolkit_ii_gallery', true ) ) :
	$ids = explode( ',', $gallery );
	if ( ! empty( $ids ) ) :
		$slides     = array();
		foreach ( $ids as $id ) {
	        if ( $image = wp_get_attachment_image_src( $id, $size_thumb ) ) {
	            $slides[] = sprintf( '<div class="item-carousel"><a href="%s"><img src="%s" alt="%s"></a></div>', get_permalink(), $image[0], get_the_title());
	        }
		}
?>
        <div class="item-thumb">
            <div class="owl-carousel single-carousel">
                <?php
				if ( ! empty( $slides ) ) {
					echo implode( '', $slides );
				}
				?>
            </div>
            <?php get_template_part( 'template/archive/parts/metadata' ); ?>
        </div>
<?php
	endif;
endif;
