<?php
	global $post;
	$post_id 			= $post->ID;
	$blog_date 			= (is_archive()) ? (int) get_theme_mod( 'blog_date', '1' ) : (int) get_theme_mod( 'single_date', '1' );
	$blog_count_comment = (is_archive()) ? (int) get_theme_mod( 'blog_count_comment', '1' ) : (int) get_theme_mod( 'single_count_comment', '1' );
	if( 1 == $blog_date || 1 == $blog_count_comment ):
?>
<div class="item-metadata k-item-metadata">
	<?php if( 1 == $blog_date ): ?>
	<span class="item-metadata-time">
		<span class="item-metadata-time-day"><?php the_time( 'j' ); ?></span>
		<span class="item-metadata-time-mon"><?php the_time( 'M' ); ?></span>
	</span>
	<?php endif; ?>
	<?php if( 1 == $blog_count_comment ): ?>
	<span class="item-metadata-comments">
		<span class="item-metadata-comments-count">
			<?php
			$comments_count = wp_count_comments( $post_id );
			$total_com = $comments_count->total_comments;
			echo esc_html( $total_com ); ?>
		</span>
		<span class="item-metadata-comments-title"><?php echo esc_html__( 'Com', 'nictitate-lite-ii' ); ?></span>
	</span>
	<?php endif; ?>
</div>
<?php
endif;