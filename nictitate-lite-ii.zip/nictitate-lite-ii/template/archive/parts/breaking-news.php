<?php
$is_enable_breaking = get_theme_mod( 'is-enable-breaking-news', 0 );
$title = get_theme_mod('breaking-news-title');
$limit = (int) get_theme_mod('breaking-news-limit', 5);
$cats  = (array)get_theme_mod('breaking-news-cats');
$cats  = implode(',', $cats);
if( !empty($cats) ){
    $result_set = new WP_Query('cat='.$cats.'&posts_per_page='.$limit);
}else{
    $result_set = new WP_Query( 'posts_per_page='.$limit);
}

if ( $is_enable_breaking ) :
?>
<div class="widget k-widget-post-single-carousel">
	<div class="overlay">
		<div class="container">
			<?php 
				if($title){
					echo '<h3 class="widget-title">'.wp_kses_post( $title ).'</h3>';
				}
			?>
			<?php if($result_set->have_posts()) : ?>
				<div class="widget-content">
					<div class="row">
						<div class="col-md-8 col-xs-12 col-md-offset-2">
							<div class="owl-carousel single-carousel">
								<?php while($result_set->have_posts()) : $result_set->the_post(); ?>
									<div class="item"><h4 class="item-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4></div>
								<?php endwhile; ?>
							</div>
						</div>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php endif;
wp_reset_postdata();