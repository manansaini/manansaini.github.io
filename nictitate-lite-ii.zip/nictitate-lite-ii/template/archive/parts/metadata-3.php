<?php
$layout_id = nictitate_lite_ii_get_template_setting();
$post_format = get_post_format();
$post_format = ( false === $post_format || 'image' === $post_format || 'aside' === $post_format || 'status' === $post_format || 'link' === $post_format || 'chat' === $post_format ) ? 'standard' : $post_format;
$sep = ( 'blog-timeline' == $layout_id) ? '&nbsp;&nbsp;|&nbsp;&nbsp;' : '&nbsp;|&nbsp;';  
$blog_date           = (int) get_theme_mod( 'blog_date', '1' );
$blog_count_comment  = (int) get_theme_mod( 'blog_count_comment', '1' );
$blog_social_sharing = (int) get_theme_mod( 'blog_social_sharing', '1' );
$show_featured_img = get_theme_mod ( 'blog_featured_img', 'show_placeholdit' ); 
if( (( ('standard' ==  $post_format) && (!has_post_thumbnail()) && ('show_placeholdit' != $show_featured_img) ) || ( 'standard' !=  $post_format )) && ( 'quote' != $post_format ) && ('gallery' !=  $post_format) ):
	if( 1 == $blog_date || 1 == $blog_count_comment || 1 == $blog_social_sharing ):
	?>
	<div class="item-metadata-3">
		<?php if( 1 == $blog_count_comment ): ?>
		<span class="item-metadata-3-comment">
			<i class="fa fa-comments-o"></i> 
			<a href="<?php the_permalink(); ?>#respond">
				<?php
				global $post;
				$comments_count = wp_count_comments( $post->ID );
				$total_com = $comments_count->total_comments;
				echo esc_html( $total_com );
				$com_text = (0 == (int)($total_com) || 1 == (int)($total_com)) ? esc_html__( ' Comment', 'nictitate-lite-ii' ) : esc_html__( ' Comments', 'nictitate-lite-ii' );
				echo esc_attr( $com_text );
				?> 
			</a>
		</span>
		<?php endif; ?>
		<?php echo esc_attr($sep); ?>
		<?php if( 'blog-timeline' != $layout_id ): ?>
			<?php if( 1 == $blog_date ): ?>
			<span class="item-metadata-3-time"><i class="fa fa-calendar"></i> <span><?php the_time('j M, Y'); ?></span></span>
			<?php endif; ?>
		<?php else: ?>
			<?php if( 1 == $blog_date ): ?>
			<span class="item-metadata-3-calendar"> <a href="<?php the_permalink(); ?>"><?php the_time('j M, Y'); ?></a></span>
			<?php endif; ?>
			<?php if( 1 == $blog_social_sharing ): ?>
			<?php echo esc_attr($sep); ?>

			<span class="item-metadata-3-share"><a href="<?php the_permalink(); ?>"><?php echo esc_html__( 'Share This Post', 'nictitate-lite-ii' ); ?></a>
				<span class="block-social">
					<a href="#"><i class="fa fa-facebook"></i>Facebook</a>
					<a href="#"><i class="fa fa-twitter"></i>Twitter</a>
					<a href="#"><i class="fa fa-google-plus"></i>Google+</a>
				</span>
			</span>   

			<?php endif; ?>
	<?php endif; ?>
	</div>
	<?php
	endif;
endif;