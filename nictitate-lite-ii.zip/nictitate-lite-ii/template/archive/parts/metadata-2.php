<?php
global $post;
$post_id     = $post->ID;
$author_id   = $post->post_author;
$layout_id   = nictitate_lite_ii_get_template_setting();
$sep = ''; 
switch ($layout_id) {
	case 'blog-default':
		$sep = '&nbsp;/&nbsp;';
		break;
	case 'blog-masonry':
		$sep = '&nbsp;|&nbsp;';
		break;
	case 'blog-timeline':
		$sep = '&nbsp;&nbsp;|&nbsp;&nbsp;';
		break;
	default:
		$sep = '&nbsp;|&nbsp;';
		break;
}
$class         = (is_singular('post')) ? 'entry-metadata' : 'item-metadata-2';
$blog_author   =  (is_archive()) ? (int) get_theme_mod( 'blog_author', '1' ) : (int) get_theme_mod( 'single_author', '1' );
$blog_category =  (is_archive()) ? (int) get_theme_mod( 'blog_category', '1' ) : (int) get_theme_mod( 'single_category', '1' );
$blog_likes    = (int) get_theme_mod( 'blog_likes', '1' );
$single_likes  = (int) get_theme_mod( 'single_likes', '1' );
if( 1 == $blog_author || 1 == $blog_category || 1 == $blog_likes || 1 == $single_likes ):
?>
<div class="<?php echo esc_attr($class); ?>">
	<?php if( 1 == $blog_author ): ?>
	<span class="item-metadata-2-author"><span><?php echo esc_html__( 'By', 'nictitate-lite-ii' ); ?></span> <a href="<?php echo get_author_posts_url( $author_id ); ?>"><?php the_author(); ?></a></span>
	<?php endif; ?>
	<?php if( 1 == $blog_category ): ?>
	<?php //echo esc_attr( $sep ); ?>
	<span class="item-metadata-2-cat">
		<span><?php echo esc_html__( 'In', 'nictitate-lite-ii' ); ?></span> 
		<?php
		$categories = get_the_category();
		$separator = ' , ';
		$output = '';
		if ( ! empty( $categories ) ) {
			foreach( $categories as $category ) {
				$output .= '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '">' . esc_html( $category->name ) . '</a>' . $separator;
			}
			echo trim( $output, $separator );
		}
		?>
	</span>
	<?php endif; ?>
	<?php 
	if( 'blog-default' == $layout_id && 1 == $blog_likes ) {
		echo esc_attr( $sep );
		$is_clickable = false;
		do_action( 'nictitate_singular_print_meta_likes', get_the_ID(), $is_clickable, '' );  
	}

	if ( is_singular('post') && 1 == $single_likes ) {
		echo esc_attr( $sep );
		$is_clickable = true;
		do_action( 'nictitate_singular_print_meta_likes', get_the_ID(), $is_clickable, 'nictitate_lite_ii_toolkit_like_clickable' );
	}
	?>
</div>
<?php endif;