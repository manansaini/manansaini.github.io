<div class="container">
    <div id="nictitate-portfolio-archive" class="widget k-widget-portfolio-filter">
        <?php
        $page_title      = get_theme_mod( 'portfolio-archive-title', esc_html__( 'Our portfolio', 'nictitate-lite-ii' ) );
        $page_desc       = get_theme_mod( 'portfolio-archive-description', '' );
        $is_show_project = (int) get_theme_mod( 'portfolio-archive-show-project', 1 );
        ?>
        <?php if ( $page_title || $page_desc ) : ?>
            <div class="widget-header">
                <?php if ( $page_title ) : ?>
                    <h3 class="widget-title"><?php echo esc_html( $page_title ); ?></h3>
                <?php endif; ?>
                <?php if ( $page_desc ) :?>
                    <p class="widget-des"><?php echo wp_kses_post( $page_desc ); ?></p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ( have_posts() ) : ?>
            <div class="widget-content">
                <div class="masonry-filter">
                    <a href="#" data-val="0" class="active"><?php esc_html_e( 'view all', 'nictitate-lite-ii' ); ?></a>
                    <?php
                        $tags    = get_terms( 'portfolio_tag' );
                        $filters = array();
                        if ( $tags ):
                            foreach ( $tags as $tag ):
                                ?>
                                <a href="#" data-val="<?php echo esc_attr( $tag->term_id ); ?>"><?php echo esc_html( $tag->name ); ?></a>
                                <?php
                            endforeach;
                        endif;
                    ?>
                </div>
                <div class="masonry-items row masonry-container">
                    <?php
                    while ( have_posts() ) :
                        the_post();
                        #Tag
                        $tags      = get_the_terms( get_the_ID(), 'portfolio_tag' );
                        $tag_ids   = array();
                        $tag_ids[] = 0;
                        if ( $tags ) {
                            foreach ( $tags as $term ) {
                                $tag_ids[] = $term->term_id;
                            }
                        }                        
                    ?>
                        <div class="item show col-md-4 col-sm-6 col-xs-12" data-val="<?php echo esc_attr( json_encode( $tag_ids ) ); ?>">
                            <div class="item-thumb">
                                <?php
                                    $lightbox = array('src' => '', 'title' => '');
                                    if ( has_post_thumbnail() ){
                                        the_post_thumbnail('nictitate_portfolio-small-ii');
                                        $thumbnail_id      = get_post_thumbnail_id( get_the_ID() );
                                        $lightbox['src']   = wp_get_attachment_image_src( $thumbnail_id, 'nictitate-lightbox' );
                                        $lightbox['title'] = get_post_field( 'post_excerpt', $thumbnail_id );                            
                                    }else{
                                        echo '<img src="//placehold.it/362x225" alt="">';
                                    }
                                ?>
                                <div class="overlay">
                                    <div>
                                        <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="fa fa-plus"></a>
                                        <?php if( $lightbox['src'] ): ?>
                                            <a href="<?php echo esc_url( $lightbox['src'][0] ); ?>" title="<?php echo esc_attr( $lightbox['title'] ); ?>" class="nictitate-gallery-item fa fa-expand"></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <h4 class="item-title">
                                <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
                            </h4>
                            <?php 
                                if( $is_show_project ) : 
                                    $projects = get_the_terms( get_the_ID(), 'portfolio_project' );
                                    if ( $projects ) :
                                        ?>
                                        <h5 class="item-cat">
                                            <?php foreach ( $projects as $term ) : ?>
                                                <a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
                                            <?php endforeach; ?>
                                        </h5>
                                        <?php 
                                    endif;
                                endif; 
                            ?>
                        </div>
                    <?php endwhile; ?>
                </div>
                <?php if( get_next_post_link() ) : ?>
                    <div class="text-center">                        
                        <span class="read-more read-more-border read-more-portfolio">
                            <?php esc_html_e('Load more', 'nictitate-lite-ii' );?>    
                        </span>
                        <?php next_posts_link( false ); ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</div>