<?php
if ( 1 !== (int) get_theme_mod( 'is-enable-breadcrumb', 1 ) ) {
    return;
}

$is_hide_breadcrumb = 0;

if( is_page() || is_single() ){
    global $post;
    $is_hide_breadcrumb = (int) get_post_meta( $post->ID, 'nictitate_lite_ii_is_hide_breadcrumb', true );
}

if( !$is_hide_breadcrumb ) :
    global $wp_query;
    $current_class = 'current-page';
    $prefix        = '&nbsp;<i class="fa fa-angle-right"></i>&nbsp;';
    
    $breadcrumb    = '';
    $page_title    = '';
    
    if ( is_archive() ) {
        if ( is_tag() ) {
            $term = get_term( get_queried_object_id(), 'post_tag' );
            $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, $term->name );
            $page_title = $term->name;
        } elseif ( is_category() ) {
            $terms_link = explode( $prefix, substr( get_category_parents( get_queried_object_id(), TRUE, $prefix ), 0, ( strlen( $prefix ) * -1 ) ) );
            $n = count( $terms_link );
            if ( $n > 1) {
                for ( $i = 0; $i < ( $n - 1 ); $i++ ) {
                    $breadcrumb .= $prefix . $terms_link[$i];
                }
            }
            $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, get_the_category_by_ID( get_queried_object_id() ) );
            $page_title = get_the_category_by_ID( get_queried_object_id() );
        } elseif ( is_year() || is_month() || is_day() ) {
            $m = get_query_var( 'm' );
            $date = array( 'y' => NULL, 'm' => NULL, 'd' => NULL );
            if ( strlen( $m ) >= 4 )
                $date['y'] = substr( $m, 0, 4 );
            if ( strlen( $m ) >= 6 )
                $date['m'] = substr( $m, 4, 2 );
            if ( strlen( $m ) >= 8 )
                $date['d'] = substr( $m, 6, 2 );
            if ( $date['y'] )
                if ( is_year() ) {
                    $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, $date['y'] );
                    $page_title = $date['y'];
                } else
                    $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', get_year_link( $date['y'] ), $date['y'] );
            if ( $date['m'] )
                if ( is_month() ) {
                    $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, date( 'F', mktime( 0, 0, 0, $date['m'] ) ) );
                    $page_title = $date['m'];
                }
                else
                    $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', get_month_link( $date['y'], $date['m']), date( 'F', mktime( 0, 0, 0, $date['m'] ) ) );
            if ( $date['d'] )
                if ( is_day() ) {
                    $page_title = $date['d'];
                    $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, $date['d'] );
                }
                else
                    $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', get_day_link( $date['y'], $date['m'], $date['d']), $date['d'] );
        } elseif ( is_author() ) {
            $author_id = get_queried_object_id();
            $page_title = sprintf( __( 'Posts created by %1$s', 'nictitate-lite-ii' ), get_the_author_meta( 'display_name', $author_id ) );
            $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, sprintf( __('Posts created by %1$s', 'nictitate-lite-ii' ), get_the_author_meta( 'display_name', $author_id ) ) );
        } elseif ( is_tax() ) {
            $term = get_queried_object();
            if ( isset( $term->taxonomy ) ) {
                $page_title = $term->name;
                $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, $term->name );
            }
        } 
        if ( class_exists( 'Nictitate_Toolkit_II_Portfolio' ) ) {
            if ( is_post_type_archive( 'portfolio' ) || is_tax( 'portfolio_tag' ) || is_tax( 'portfolio_project' ) ) {
                $page_title = esc_html__( 'Our portfolio', 'nictitate-lite-ii' );
                $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, esc_html__( 'Our portfolio', 'nictitate-lite-ii' ) );
            }
        }
        if ( class_exists('Nictitate_Toolkit_II_Service') ) {
            if ( is_post_type_archive( 'service' ) || is_tax( 'service_tag' ) || is_tax( 'service_category' ) ) {
                $page_title = esc_html__( 'Our service', 'nictitate-lite-ii' );
                $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, esc_html__( 'Our service', 'nictitate-lite-ii' ) );
            }
        }  
    } elseif ( is_search() ) {
        $page_title = esc_html__( 'Search result', 'nictitate-lite-ii' );
        $s          = get_search_query();
        $breadcrumb .= $prefix . sprintf( '<span itemprop="title" class="%1$s">%2$s</span>', $current_class, esc_html__( 'Search', 'nictitate-lite-ii' ) . ' "' . esc_html($s) . '"' );
    } elseif ( is_singular() ) {
        if ( is_page() ) {
            $page_title = get_the_title( get_queried_object_id() );
            if ( is_front_page() ) {
                $breadcrumb = NULL;
            } else {
                $post_ancestors = get_post_ancestors( $post );
                if ( $post_ancestors ) {
                    $post_ancestors = array_reverse( $post_ancestors );
                    foreach ( $post_ancestors as $crumb )
                        $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', get_permalink( $crumb ), esc_html( get_the_title( $crumb ) ) );
                }
                $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url" href="%2$s"><span itemprop="title">%3$s</span></a></span>', $current_class, get_permalink( get_queried_object_id() ), esc_html( get_the_title( get_queried_object_id() ) ) );
            }
        } else {
            if ( is_single() ) {
                $categories = get_the_category( get_queried_object_id() );
                if ( $categories ) {
                    foreach ( $categories as $category ) {
                        $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a href="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', get_category_link( $category->term_id ), $category->name );
                    }
                }
            }        
            $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url" href="%2$s"><span itemprop="title">%3$s</span></a></span>', $current_class, get_permalink( get_queried_object_id() ), esc_html( get_the_title( get_queried_object_id() ) ) );
            $page_title = get_the_title( get_queried_object_id() );
        }
    } elseif ( is_404() ) {
        $page_title = esc_html__( 'Page not found', 'nictitate-lite-ii' );
        $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, esc_html__( 'Page not found', 'nictitate-lite-ii' ) );
    } elseif ( is_home() ) {
        $page_title = esc_html__( 'Latest News', 'nictitate-lite-ii' );
        $breadcrumb .= $prefix . sprintf( '<span itemscope itemtype="http://data-vocabulary.org/Breadcrumb"><a class="%1$s" itemprop="url"><span itemprop="title">%2$s</span></a></span>', $current_class, esc_html__( 'Latest News', 'nictitate-lite-ii' ) );
    }

    ob_start();
    ?>
    <div class="heading-page">
        <div class="overlay">
            <div class="container">
                <?php if ( ! empty( $page_title ) ) : ?>
                <h2 class="heading-page-title"><?php echo esc_html( $page_title ); ?></h2>
                <?php endif; ?>
                <div class="kopa-breadcrumb">
                    <span itemscope="" itemtype="http://data-vocabulary.org/Breadcrumb">
                        <a itemprop="url" href="<?php echo home_url('/'); ?>">
                            <span itemprop="title"><?php esc_html_e( 'Home', 'nictitate-lite-ii' ); ?></span>
                        </a>
                    </span>
                    <?php echo wp_kses( $breadcrumb , nictitate_lite_ii_get_allowed_tags() ); ?>
                </div>
            </div>
        </div>
    </div>
    <?php
    $html = ob_get_clean();
    do_action( 'nictitate_breadcrumb' );
    echo apply_filters( 'nictitate_get_breadcrumb', $html );

endif;