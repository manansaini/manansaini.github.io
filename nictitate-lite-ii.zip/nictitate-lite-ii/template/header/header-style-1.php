<div class="header-page header-page-1">
    <div class="top-header-page ">
        <div class="container">
            <div class="top-logo">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="logo" title="<?php echo esc_attr(get_bloginfo('name', 'display'));?>">
                    <?php get_template_part('template/header/parts/logo'); ?>
                </a>
            </div>
            <?php get_template_part('template/header/parts/info-full'); ?>
        </div>
    </div>
    <!-- top header -->
    <div class="bottom-header-page">
        <div class="container">
            <div class="inner-bottom-header-page clearfix">
                <?php
                get_template_part('template/header/parts/logo-mobile');

                if( has_nav_menu( 'main-nav' ) ){
                    echo '<a href="#mobile-menu" class="mobile-menu fa fa-bars"></a>';
                    $args = array(
                        'theme_location' => 'main-nav',
                        'container'      => false,
                        'menu_class'     => 'sf-menu',
                    );
                    wp_nav_menu( $args );
                }

                get_template_part('template/header/parts/social-follow');
                get_template_part('template/header/parts/search');
                ?>
            </div>
        </div>
    </div>
    <!-- bottom header -->
</div>
<!-- header page -->
<?php 
get_template_part('template/header/parts/menu-mobile');