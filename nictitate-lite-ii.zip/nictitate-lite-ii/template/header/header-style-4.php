<div class="header-page header-page-4">
    <div class="top-header-page clearfix">
        <div class="container">
            <div class="inner-top-header-page">
                <?php get_template_part( 'template/header/parts/logo-mobile' ); ?>
                <?php
                    $nictitate_add = get_theme_mod( 'header-address', '' );
                    if ( ! empty( $nictitate_add ) ) :
                ?>
                    <div class="info-ad"><span><?php echo esc_html( $nictitate_add ); ?></span></div>
                <?php endif; ?>
                <div class="pull-right">
                    <a href="#mobile-menu" class="mobile-menu fa fa-bars"></a>
                    <?php
                        get_template_part( 'template/header/parts/social-follow' );
                        get_template_part( 'template/header/parts/search' );
                    ?>
                </div>
            </div>
        </div>
    </div>
    <div class="middle-header-page clearfix">
        <div class="container">
            <div class="inner-top-middle-page">
                <div class="top-logo">
                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>">
                        <?php get_template_part( 'template/header/parts/logo' ); ?>
                    </a>
                </div>
                <?php get_template_part( 'template/header/parts/info-full' ); ?>
            </div>
        </div>
    </div>
    <div class="bottom-header-page clearfix">
        <div class="container">
            <div class="inner-bottom-header-page">
                <?php get_template_part( 'template/header/parts/menu' ); ?>
            </div>
        </div>
    </div>
</div>
<?php 
get_template_part( 'template/header/parts/menu-mobile' );