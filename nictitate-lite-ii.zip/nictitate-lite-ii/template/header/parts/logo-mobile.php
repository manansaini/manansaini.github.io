<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="m-logo">
    <?php
	    if ( $logo_mobile = get_theme_mod( 'logo-mobile', '' ) ){
	        echo '<img src="'.esc_url( $logo_mobile ).'" alt="">';
	    } else {
	        echo '<h1>';
	        echo esc_html( get_bloginfo('name', 'display') );
	        echo '</h1>';
	    }
    ?>
</a>