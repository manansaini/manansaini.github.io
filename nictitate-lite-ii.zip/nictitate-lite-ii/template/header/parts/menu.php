<?php
	if ( has_nav_menu( 'main-nav' ) ) {
	    $args = array(
			'theme_location' => 'main-nav',
			'container'      => false,
			'menu_class'     => 'sf-menu'
	    );
	    wp_nav_menu( $args );
	}
