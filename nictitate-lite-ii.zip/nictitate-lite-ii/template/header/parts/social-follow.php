<?php

$nictitate_lite_ii_socials      = nictitate_lite_ii_get_socials();
$nictitate_lite_ii_show_social  = (int) get_theme_mod( 'header-show-social', 1 );
$nictitate_lite_ii_socials_data = array();

if ( $nictitate_lite_ii_socials ) {
    foreach ( $nictitate_lite_ii_socials as $v ) {
        $nictitate_curr_value = get_theme_mod( 'social_share_' . esc_attr( $v['id'] ),'' );
        if ( 'rss' === $v['id'] ) {
            if ( 'HIDE' !== $nictitate_curr_value ) {
                $nictitate_lite_ii_socials_data[] = $v;
            }
        } else {
            if ( ! empty( $nictitate_curr_value ) ) {
                $nictitate_lite_ii_socials_data[] = $v;
            }
        }
    }
}
if ( $nictitate_lite_ii_socials_data && 1 === $nictitate_lite_ii_show_social ) : ?>
    <div class="list-social">
        <?php
            foreach ( $nictitate_lite_ii_socials_data as $v ) {
                $curr_value = get_theme_mod( 'social_share_' . esc_attr( $v['id'] ),'' );
                if ( 'rss' === $v['id'] ) {
                    if ( empty( $curr_value ) ) {
                        $curr_value = get_bloginfo( 'rss2_url' );
                    }
                }
                ?>
                <a href="<?php echo esc_url( $curr_value ); ?>" rel="nofollow" title="<?php echo esc_html__( 'Follow us via ', 'nictitate-lite-ii' ) . esc_html( $v['title'] ); ?>" target="_blank" class="<?php echo esc_attr( $v['icon'] ); ?>"></a>
                <?php
            }
        ?>
    </div>
<?php 
endif;