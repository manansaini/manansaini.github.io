<?php
if ( has_nav_menu( 'main-nav' ) ) {
    $args = array(
        'theme_location' => 'main-nav',
        'container'      => false,
        'menu_class'     => 'sf-menu',
    );
    if ( class_exists( 'Nictitate_Lite_II_Toolkit_Walker_Icon_Menu' ) ) {
        $args['walker'] = new Nictitate_Lite_II_Toolkit_Walker_Icon_Menu();
    }
    wp_nav_menu( $args );
}
