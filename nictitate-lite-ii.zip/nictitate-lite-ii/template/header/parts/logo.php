<?php
if ( $nictitate_lite_ii_logo = get_theme_mod( 'logo', '' ) ) {
    echo '<img src="' . esc_url( $nictitate_lite_ii_logo ) . '" alt="' . esc_attr( get_bloginfo( 'name', 'display' ) ) . '" title="' . esc_attr( get_bloginfo( 'name', 'display' ) ) . '">';
} else {
	?>
		<h1><?php echo esc_html( get_bloginfo( 'name', 'display') ); ?></h1>
	<?php  
}