<?php

$nictitate_lite_ii_phone     = get_theme_mod( 'header-phone', '' );
$nictitate_lite_ii_open_text = get_theme_mod( 'header-open-text', '' );

if ( ! empty( $nictitate_lite_ii_phone ) || ! empty( $nictitate_lite_ii_open_text ) ) :
?>
    <div class="info-c">
        <ul class="list-unstyled clearfix">
            <?php if ( ! empty( $nictitate_lite_ii_phone ) ) : ?>
                <li>
                    <i class="fa fa-phone"></i>
                    <?php if ( ! empty( $nictitate_lite_ii_phone ) ) : ?>
                        <strong><?php echo esc_html( $nictitate_lite_ii_phone ); ?></strong>
                    <?php endif; ?>
                </li>
            <?php endif; ?>
            <?php if ( ! empty( $nictitate_lite_ii_open_text ) ) : ?>
                <li>
                    <i class="fa fa-clock-o"></i>
                    <?php if ( ! empty( $nictitate_lite_ii_open_text ) ) : ?>
                        <strong><?php echo esc_html( $nictitate_lite_ii_open_text ); ?></strong>
                    <?php endif; ?>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif;