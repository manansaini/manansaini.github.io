<?php 
	$nictitate_lite_ii_search = (int) get_theme_mod( 'header-show-search', 1 );
	if ( 1 === $nictitate_lite_ii_search ) :
?>

<div id="sb-search" class="sb-search">
    <form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
        <input class="sb-search-input" placeholder="<?php  esc_html_e( 'Enter your search term...', 'nictitate-lite-ii' ); ?>" type="text" value="" name="s" id="search">
        <input class="sb-search-submit" type="submit" value="">
        <span class="sb-icon-search fa fa-search"></span>
    </form>
</div>

<?php endif;