<div id="mobile-menu">
    <?php
        if ( has_nav_menu( 'mobile-nav' ) ) {
            $args = array(
                'theme_location' => 'mobile-nav',
                'container'      => false,
                'menu_class'     => '',
            );
            wp_nav_menu( $args );
        }    
    ?>
</div>