<?php

$nictitate_lite_ii_phone      = get_theme_mod( 'header-phone', '' );
$nictitate_lite_ii_email      = get_theme_mod( 'header-email', '' );
$nictitate_lite_ii_open_text  = get_theme_mod( 'header-open-text', '' );
$nictitate_lite_ii_close_text = get_theme_mod( 'header-close-text', '' );

if ( ! empty( $nictitate_lite_ii_phone ) || ! empty( $nictitate_lite_ii_email ) || ! empty( $nictitate_lite_ii_open_text ) || ! empty( $nictitate_lite_ii_close_text ) ) :
?>
<div class="info-c">
    <ul class="list-unstyled clearfix">
        <?php if ( ! empty( $nictitate_lite_ii_phone ) || ! empty( $nictitate_lite_ii_email ) ) : ?>
            <li>
                <i class="fa fa-phone"></i>
                <?php if ( ! empty( $nictitate_lite_ii_phone ) ) : ?>
                    <strong><?php echo esc_html( $nictitate_lite_ii_phone ); ?></strong>
                <?php endif; ?>
                <?php if ( ! empty( $nictitate_lite_ii_email ) ) : ?>
                    <span><?php echo esc_html( $nictitate_lite_ii_email ); ?></span>
                <?php endif;?>
            </li>
        <?php endif; ?>
        <?php if ( ! empty( $nictitate_lite_ii_open_text ) || ! empty( $nictitate_lite_ii_close_text ) ) : ?>
            <li>
                <i class="fa fa-clock-o"></i>
                <?php if ( ! empty( $nictitate_lite_ii_open_text ) ) : ?>
                    <strong><?php echo esc_html( $nictitate_lite_ii_open_text ); ?></strong>
                <?php endif; ?>
                <?php if ( ! empty( $nictitate_lite_ii_close_text ) ) : ?>
                    <span><?php echo esc_html( $nictitate_lite_ii_close_text ); ?></span>
                <?php endif; ?>
            </li>
        <?php endif; ?>
    </ul>
</div>
<?php endif;