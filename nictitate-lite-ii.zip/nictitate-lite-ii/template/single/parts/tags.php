<?php
$single_tags = (int) get_theme_mod( 'single_tags', '1' );
if( 1 == $single_tags ):
?>
<div class="box-tags-post">
	<?php the_tags('', '', ''); ?>
</div>
<?php
endif;
