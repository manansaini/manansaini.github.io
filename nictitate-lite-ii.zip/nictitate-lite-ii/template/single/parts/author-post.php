<?php
global $post;
$author_id           = $post->post_author;
$single_about_author = (int) get_theme_mod( 'single_about_author', '1' );
if( 1 == $single_about_author ):
?>
<div class="box-user-post">
	<div class="box-user-avatar">
		<?php echo get_avatar( get_the_author_meta('user_email'), '117'); ?>
	</div>
	<h4 class="box-user-title"><?php the_author(); ?></h4>
	<div class="box-user-description">
		<p><?php echo get_the_author_meta('description', $author_id); ?></p>
	</div>
	<?php do_action('nictitate_print_single_post_author'); ?>
</div>
<?php
endif;