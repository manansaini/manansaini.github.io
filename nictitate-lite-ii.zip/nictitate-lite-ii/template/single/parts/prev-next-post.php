<?php
	global $post;
	$prev_post 		  = get_previous_post();
	$next_post 		  = get_next_post();
	$single_prev_next = (int) get_theme_mod( 'single_prev_next', '1' );
	if( 1 == $single_prev_next ):
?>
<nav class="k-post-navigation">
	<div class="nav-links">
		<?php if( $prev_post ): ?>
		<div class="nav-previous">
			<a href="<?php echo get_permalink( $prev_post ); ?>" rel="prev">
				<span class="meta-nav fa fa-angle-left" aria-hidden="true"></span> 
				<div>
				<?php if(!has_post_thumbnail( $prev_post->ID )): ?>
					<img src="http://placehold.it/100x72" alt="">
				<?php else: ?>
					<?php $prev_thumb = wp_get_attachment_image_src(get_post_thumbnail_id( $prev_post->ID), 'nictitate-prev-next-post'); ?>
					<img src="<?php echo esc_url($prev_thumb[0]); ?>" alt="" />
				<?php endif; ?>
					<span class="post-title"><?php echo get_the_title( $prev_post ); ?></span>
				</div>
			</a>
		</div>
		<?php endif; ?>
		<?php if( $next_post ): ?>
		<div class="nav-next">
			<a href="<?php echo get_permalink( $next_post ); ?>" rel="next">
				<span class="meta-nav fa fa-angle-right" aria-hidden="true"></span> 
				<div>
				<?php if(!has_post_thumbnail( $next_post->ID )): ?>
					<img src="http://placehold.it/100x72" alt="">
				<?php else: ?>
					<?php $next_thumb = wp_get_attachment_image_src(get_post_thumbnail_id( $next_post->ID), 'nictitate-prev-next-post'); ?>
					<img src="<?php echo esc_url($next_thumb[0]); ?>" alt="" />
				<?php endif; ?>
					<span class="post-title"><?php echo get_the_title( $next_post ); ?></span>
				</div>
			</a>
		</div>
		<?php endif; ?>
	</div>
</nav>
<?php
endif;