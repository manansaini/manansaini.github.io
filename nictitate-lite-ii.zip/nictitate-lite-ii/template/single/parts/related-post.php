<?php
global $post;
$taxs   = array();
$get_by = get_theme_mod ( 'single_relate_get_by', 'category' ); 
$limit  = (int)get_theme_mod ( 'single_relate_limit', '3' );
if( 0 < $limit ): 

    if ( 'category' == $get_by ) {
        $cats = get_the_category( $post->ID );
        if ( $cats ) {
            $ids = array();
            foreach ( $cats as $cat ) {
                $ids[] = $cat->term_id;
            }
            $taxs [] = array(
                'taxonomy' => 'category',
                'field'    => 'id',
                'terms'    => $ids,
                );
        }
    } else if ( 'post_tag' == $get_by ) {
        $tags = get_the_tags( $post->ID );
        if ( $tags ) {
            $ids = array();
            foreach ( $tags as $tag ) {
                $ids[] = $tag->term_id;
            }
            $taxs [] = array(
                'taxonomy' => 'post_tag',
                'field'    => 'id',
                'terms'    => $ids,
                );
        }
    }

    if ( $taxs ) :
        $related_args = array(
            'post_type'      => array( $post->post_type ),
            'tax_query'      => $taxs,
            'post__not_in'   => array( $post->ID ),
            'posts_per_page' => $limit,
            );

        $related_posts = new WP_Query( $related_args );
        if( $related_posts->have_posts() ): ?>
            <div class="widget k-related-post">
                <h3 class="widget-title"><?php echo esc_html__( 'Related Articles', 'nictitate-lite-ii' ); ?></h3>
                <div class="widget-content">
                    <div class="row">
                        <?php 
                        while( $related_posts->have_posts() ): $related_posts->the_post();
                        ?>
                        <div class="col-md-4 col-sm-4 col-xs-12">
                            <div class="item">
                                <div class="item-thumb">
                                    <a href="<?php the_permalink(); ?>">
                                    <?php if( !has_post_thumbnail() ): ?>
                                        <img src="http://placehold.it/266x183" alt="">
                                    <?php else: ?>
                                        <?php the_post_thumbnail( 'nictitate-related-post', array('title' => get_the_title(), 'alt' => '')); ?>
                                    <?php endif; ?>
                                    </a>
                                </div>
                                <h4 class="item-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
                                <div class="item-metadata">
                                    <?php the_time('F j, Y' ); ?>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    </div>
                </div>
            </div>
    <?php
        endif;
        wp_reset_postdata();
    endif; 
endif; ?>