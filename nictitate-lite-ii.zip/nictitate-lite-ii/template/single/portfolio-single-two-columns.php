<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
        <?php
            $nictitate_lite_ii_gallery = get_post_meta( get_the_ID(), 'portfolio_gallery', true );
            $nictitate_lite_ii_client  = get_post_meta( get_the_ID(), 'portfolio_client', true );
            $nictitate_lite_ii_date    = get_post_meta( get_the_ID(), 'portfolio_date', true );
            $nictitate_lite_ii_web     = get_post_meta( get_the_ID(), 'portfolio_website', true );
            $cols['right']['classes'] = empty( $nictitate_lite_ii_gallery ) ? array( 'col-md-12 col-sm-12 col-xs-12' ) : array('col-md-4', 'col-sm-4', 'col-xs-12');
        ?>
        <div class="container">
            <div <?php post_class( 'entry-portfolio' ); ?>>
                <div class="row">
                    <?php if ( ! empty( $nictitate_lite_ii_gallery ) ) : ?>
                        <div class="col-md-8 col-sm-8 col-xs-12">
                            <div class="entry-thumb">
                                <div class="owl-carousel single-carousel">
                                    <?php
                                    $nictitate_lite_ii_ids = explode( ',', $nictitate_lite_ii_gallery );
                                    foreach ( $nictitate_lite_ii_ids as $id ) :
                                        $nictitate_image_src = nictitate_lite_ii_get_image_src( $id, 'nictitate_portfolio-medium-ii' );
                                        if ( ! empty( $nictitate_image_src ) ) :
                                            $image_caption = get_post_field( 'post_excerpt', $id );
                                            ?>
                                            <div class="item"><img src="<?php echo esc_url( $nictitate_image_src ); ?>" alt="<?php echo esc_attr( $image_caption ); ?>"></div>
                                            <?php
                                        endif;
                                    endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="<?php echo esc_attr( implode( ' ', $cols['right']['classes'] ) ); ?>">
                        <h1 class="entry-title"><?php the_title();?></h1>
                        <div class="entry-content">
                            <?php the_content(); ?>
                            <?php wp_link_pages(); ?>
                        </div>
                        <?php if ( ! empty($nictitate_lite_ii_client) || ! empty($nictitate_lite_ii_date) ) : ?>
                            <div class="box-meta k-font-heading">
                                <ul class="list-unstyled">
                                    <?php if ( ! empty( $nictitate_lite_ii_client ) ) : ?>
                                        <li>
                                            <span><?php esc_html_e( 'Client:', 'nictitate-lite-ii' ); ?></span> 
                                            <?php echo esc_html( $nictitate_lite_ii_client ); ?>
                                        </li>
                                    <?php endif; ?>
                                    <?php if ( ! empty( $nictitate_lite_ii_date ) ) : ?>
                                        <li>
                                            <span><?php esc_html_e( 'Date:', 'nictitate-lite-ii' ); ?></span> 
                                            <?php echo esc_html( date( get_option( 'date_format'), $nictitate_lite_ii_date ) ); ?> 
                                        </li>
                                    <?php endif; ?>
                                </ul>
                            </div>                            
                        <?php endif; ?>
                        <?php if ( ! empty( $nictitate_lite_ii_web ) ) : ?>
                            <a href="<?php echo esc_url( $nictitate_lite_ii_web ); ?>" target="_blank" class="read-more read-more-border read-more-arrow"><?php esc_html_e( 'visit website', 'nictitate-lite-ii' ); ?></a>
                        <?php endif; ?>
                        <?php
                            $nictitate_prev_post = get_previous_post();
                            $nictitate_next_post = get_next_post();
                            if( $nictitate_prev_post || $nictitate_next_post ):
                        ?>
                            <div class="box-controls">
                                <?php if ( $nictitate_prev_post ) : ?>
                                    <a href="<?php echo esc_url( get_permalink( $nictitate_prev_post ) ); ?>" title="<?php echo esc_attr( get_the_title( $nictitate_prev_post ) ); ?>" class="fa fa-angle-left"></a>
                                <?php endif; ?>
                                <a href="<?php echo esc_url( get_post_type_archive_link( 'portfolio' ) ); ?>" title="<?php esc_html_e( 'Show all portfolios', 'nictitate-lite-ii' ); ?>" class="fa fa-th-large"></a>
                                <?php if ( $nictitate_next_post ) : ?>
                                    <a href="<?php echo esc_url( get_permalink( $nictitate_next_post ) ); ?>" title="<?php echo esc_attr( get_the_title( $nictitate_next_post ) ); ?>" class="fa fa-angle-right"></a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>     
            <div id="nictitate_portfolio_comments" class="nictitate-style-1 clearfix">
                <?php comments_template(); ?>           
            </div>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <?php printf( '<blockquote>%1$s</blockquote>', esc_html__( 'Nothing Found...', 'nictitate-lite-ii' ) ); ?>
<?php endif; ?>