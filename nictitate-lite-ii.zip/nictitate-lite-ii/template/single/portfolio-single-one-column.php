<?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
		<?php
			$nictitate_lite_ii_gallery = get_post_meta( get_the_ID(), 'portfolio_gallery', true );
			$nictitate_lite_ii_client  = get_post_meta( get_the_ID(), 'portfolio_client', true );
			$nictitate_lite_ii_date    = get_post_meta( get_the_ID(), 'portfolio_date', true) ;
			$nictitate_lite_ii_web     = get_post_meta( get_the_ID(), 'portfolio_website', true );
		?>
		<div class="container">
		    <div <?php post_class( array( 'entry-portfolio', 'entry-portfolio-2' ) ); ?>>
		        <?php if ( ! empty( $nictitate_lite_ii_gallery ) ) : ?>
		            <div class="entry-thumb">
		                <div class="owl-carousel single-carousel">
		                    <?php
			                    $nictitate_lite_ii_ids = explode( ',', $nictitate_lite_ii_gallery );
			                    foreach ( $nictitate_lite_ii_ids as $id ) :
			                        $nictitate_lite_ii_image_src = nictitate_lite_ii_get_image_src( $id, 'nictitate_portfolio-big-ii' );
			                        if ( ! empty( $nictitate_lite_ii_image_src ) ) :
			                            $image_caption = get_post_field( 'post_excerpt', $id );
			                            ?>
			                            <div class="item"><img src="<?php echo esc_url( $nictitate_lite_ii_image_src ); ?>" alt="<?php echo esc_attr( $image_caption ); ?>"></div>
			                            <?php
			                        endif;
			                    endforeach; 
		                    ?>
		                </div>
		            </div>			            
		        <?php endif; ?>
		        <div class="row">
		            <div class="col-md-8 col-sm-8 col-xs-12">
		                <h1 class="entry-title"><?php the_title();?></h1>
		                <div class="entry-content">
		                    <?php the_content(); ?>
		                    <?php wp_link_pages(); ?>
		                </div>
		                <?php if ( ! empty( $nictitate_lite_ii_web ) ) : ?>
		                    <a href="<?php echo esc_url( $nictitate_lite_ii_web ); ?>" target="_blank" class="read-more read-more-border read-more-arrow"><?php esc_html_e( 'visit website', 'nictitate-lite-ii' ); ?></a>
		                <?php endif; ?>
		            </div>
		            <div class="col-md-4 col-sm-4 col-xs-12">
		                <?php if ( ! empty( $nictitate_lite_ii_client ) || ! empty( $nictitate_lite_ii_date ) ) : ?>
		                    <div class="box-meta k-font-heading">
		                        <ul class="list-unstyled">
		                            <?php if ( ! empty( $nictitate_lite_ii_client ) ) : ?>
		                            	<li>
		                            		<span><?php esc_html_e( 'Client:', 'nictitate-lite-ii' ); ?></span> 
		                            		<?php echo esc_html( $nictitate_lite_ii_client ); ?>
		                            	</li>
		                            <?php endif; ?>
		                            <?php if ( ! empty( $nictitate_lite_ii_date ) ) : ?>
		                            	<li>
		                            		<span><?php esc_html_e( 'Date:', 'nictitate-lite-ii' );?></span> 
		                            		<?php echo esc_html( date( get_option( 'date_format'), $nictitate_lite_ii_date ) ); ?> 
		                            	</li>
		                            <?php endif; ?>
		                        </ul>
		                    </div>			                    
		                <?php endif; ?>
		                <?php
			                $nictitate_lite_ii_prev_post = get_previous_post();
			                $nictitate_lite_ii_next_post = get_next_post();
		                ?>
		                <?php if ( $nictitate_lite_ii_prev_post || $nictitate_lite_ii_next_post ) : ?>
			                <div class="box-controls">
			                    <?php if ( $nictitate_lite_ii_prev_post ) : ?>
			                        <a href="<?php echo esc_url( get_permalink( $nictitate_lite_ii_prev_post ) ); ?>" title="<?php echo esc_attr( get_the_title( $nictitate_lite_ii_prev_post ) ); ?>" class="fa fa-angle-left"></a>
			                    <?php endif; ?>
			                    <a href="<?php echo esc_url( get_post_type_archive_link( 'portfolio' ) ); ?>" title="<?php esc_html_e( 'Show all portfolios', 'nictitate-lite-ii'); ?>" class="fa fa-th-large"></a>
			                    <?php if ( $nictitate_lite_ii_next_post ) : ?>
			                    	<a href="<?php echo esc_url(get_permalink( $nictitate_lite_ii_next_post ) ); ?>" title="<?php echo esc_attr( get_the_title( $nictitate_lite_ii_next_post ) ); ?>" class="fa fa-angle-right"></a>
			                    <?php endif; ?>
			                </div>
			            <?php endif; ?>
		            </div>
		        </div>
		    </div>
		    <div id="nictitate_portfolio_comments" class="nictitate-style-2 clearfix">
                <?php comments_template(); ?>           
            </div>
		</div>
    <?php endwhile; ?>
<?php else: ?>
	<?php printf( '<blockquote>%1$s</blockquote>', esc_html__( 'Nothing Found...', 'nictitate-lite-ii' ) ); ?>
<?php endif; ?>