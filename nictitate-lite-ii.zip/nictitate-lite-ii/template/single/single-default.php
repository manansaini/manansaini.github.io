<?php 
	$sb_right = apply_filters( 'nictitate_lite_ii_get_sidebar', 'sb_right', 'pos_right' );
	$cols['left']['classes']  = array( 'col-xs-12' );
	$cols['right']['classes'] = array( 'col-xs-12' );
	if ( is_active_sidebar( $sb_right ) ) {
		array_push( $cols['left']['classes'], 'col-md-9' );
		array_push( $cols['right']['classes'], 'col-md-3' );
	}
?>
<div class="container">
	<div class="row">
		<div class="<?php echo esc_attr( implode(' ', $cols['left']['classes'] ) ); ?>">
			<div class="main-section">  
				<?php if ( have_posts() ) : ?>
					<?php while( have_posts() ) : the_post(); ?>
						<div <?php post_class( 'entry-post' ); ?>>
							<?php 							
								$post_format = get_post_format();
								$post_format = ( false === $post_format || 'image' === $post_format || 'aside' === $post_format || 'status' === $post_format || 'chat' === $post_format ) ? 'standard' : $post_format;
								get_template_part( 'template/archive/parts/post-thumbnail/type', $post_format ); 
							?>
							<div class="entry-header">
								<h1 class="entry-title"><?php the_title(); ?></h1>
								<?php get_template_part( 'template/archive/parts/metadata-2' ); ?>
							</div>
							<div class="entry-content">
								<?php the_content(); ?>
								<?php wp_link_pages(); ?>
							</div>
						</div>
						<?php get_template_part( 'template/single/parts/prev-next-post' ); ?>
						<?php get_template_part( 'template/single/parts/tags' ); ?>
						<?php do_action( 'nictitate_lite_ii_share_post' ); ?>
						<?php get_template_part( 'template/single/parts/author-post' ); ?>
						<?php get_template_part( 'template/single/parts/related-post' ); ?>
						<?php comments_template(); ?>
					<?php endwhile; ?>
				<?php else: ?>
					<?php printf( '<blockquote>%1$s</blockquote>', esc_html__( 'Nothing Found...', 'nictitate-lite-ii' ) ); ?>
				<?php endif; ?>
			</div>
		</div>
		<?php if ( is_active_sidebar( $sb_right ) ) : ?>
			<div class="<?php echo esc_attr( implode(' ', $cols['right']['classes'] ) ); ?>">
				<div class="sidebar">
					<?php dynamic_sidebar( $sb_right ); ?>
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>