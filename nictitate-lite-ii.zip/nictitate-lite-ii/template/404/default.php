<div class="container">
    <div class="widget kopa_module_404">
        <div class="widget-content">
            <header>
                <h3><?php esc_html_e( 'We are sorry !', 'nictitate-lite-ii' ); ?></h3>
                <p><?php printf( "Can't find what you need? Take a moment and do search <br>below or start from our <a href='%s'>homepage</a>",  esc_url( home_url( '/' ) ) ) ?></p>
            </header>
            <p><?php esc_html_e( '404', 'nictitate-lite-ii' ); ?></p>
            <div class="row">
                <div class="col-md-push-3 col-sm-push-3 col-xs-push-0 col-md-6 col-sm-6 col-xs-12">
                    <div class="widget-content">
                        <form class="error-search-form" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                            <div class="row">
                                <div class="col-md-9 col-sm-9 col-xs-9">
                                    <input type="text" placeholder="<?php esc_html_e( 'Enter your search term...', 'nictitate-lite-ii' ); ?>" size="40" class="email" value="" name="s" id="search">
                                </div>
                                <div class="col-md-3 col-sm-3 col-xs-3">
                                    <input type="submit" class="submit" value="<?php esc_attr_e( 'Send', 'nictitate-lite-ii' ); ?>">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>