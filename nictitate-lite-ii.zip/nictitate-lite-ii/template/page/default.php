<div class="widget-area-1">
    <div class="widget k-widget has-header k-widget-demo">
        <div class="overlay">
            <div class="container">                    
                <div class="widget-content">
                    <?php
                        if ( have_posts() ) :
                            while ( have_posts() ) : the_post();
                                ?>
                                <div <?php post_class( 'entry-content'); ?>>
                                    <?php the_content(); ?>
                                    <?php wp_link_pages(); ?>
                                </div>
                                <?php
                                comments_template();
                            endwhile;
                        else:                                
                            printf( '<blockquote>%1$s</blockquote>', esc_html__( 'Nothing Found...', 'nictitate-lite-ii' ) );
                        endif;
                    ?>                      
                </div>
            </div>
        </div>
    </div>
</div>