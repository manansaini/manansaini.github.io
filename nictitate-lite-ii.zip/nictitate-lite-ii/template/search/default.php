<?php  
	$sb_right = apply_filters( 'nictitate_lite_ii_get_sidebar', 'sb_right', 'pos_right' ); 
?>
<div class="container">
	<div class="row">
		<div class="col-md-9 col-xs-12">
			<div class="main-section">
				<?php if ( have_posts() ) : ?>
					<?php
						$excerpt_length = (int) get_theme_mod( 'blog_excerpt_length', 10 );
						if ( ! isset( $excerpt_length ) || empty( $excerpt_length ) ) {
							$excerpt_length = 10;
						}
						$GLOBALS['nictitate_lite_ii_excerpt_length'] = (int) $excerpt_length;
						add_filter( 'excerpt_length', 'nictitate_lite_ii_set_excerpt_length' ); 
					?>
					<ul class="list-blog-post">
						<?php while( have_posts() ) : the_post(); ?>
							<li <?php post_class( 'item' ); ?>>
								<div class="item-inner">								
									<div class="item-content">
										<h4 class="item-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
										<?php get_template_part( 'template/archive/parts/metadata-2' ); ?>								
										<?php the_excerpt(); ?>
										<?php get_template_part( 'template/archive/parts/readmore' ); ?>
									</div>
								</div>
							</li>
						<?php endwhile; ?>
					</ul>
					<?php remove_filter( 'excerpt_length', 'nictitate_lite_ii_set_excerpt_length' ); ?>
					<?php get_template_part( 'template/pagination' ); ?>
				<?php else: ?>
					<?php printf( '<blockquote>%1$s</blockquote>', esc_html__( 'Nothing Found...', 'nictitate-lite-ii' ) ); ?>
				<?php endif; ?>
			</div>  
		</div>
		<div class="col-md-3 col-xs-12">
			<div class="sidebar">
				<?php dynamic_sidebar( $sb_right ); ?>
			</div>
		</div>
	</div>          
</div>